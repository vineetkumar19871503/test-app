const securityQuestionModel = require('../../db/schemas/SecurityQuestionSchema').models.securityQuestionModel;
    
module.exports = {

    getSecurityQuestion: function (conditions = {}, fields = {}) {
        return new Promise(function (resolve, reject) {
            var query = securityQuestionModel.find(conditions);
            if (Object.keys(fields).length) {
                query.select(fields);
            }
            query.exec(function (err, question) {
                err ? reject(err) : resolve(question);
            });
        });
    },
}