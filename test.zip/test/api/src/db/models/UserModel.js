const bcrypt = require('bcrypt'),
    config = require('../../../config'),
    userSchema = require('../../db/schemas/UserSchema'),
    userContactsModel = require('../../db/schemas/UserSchema').models.userContactsModel,
    userModel = userSchema.models.userModel;
   
module.exports = {
    getUsers: function (conditions = {}, fields = {}) {
        const self = this;
        return new Promise(function (resolve, reject) {
            var query = [
                {
                    $lookup: {
                        from: 'roles',
                        localField: 'role_id',
                        foreignField: '_id',
                        as: 'role'
                    }
                },
                {
                    $lookup: {
                        from: 'permission_modules',
                        localField: 'role.permissions.permission_module_id',
                        foreignField: '_id',
                        as: 'permission_modules'
                    }
                },
                {
                    $lookup: {
                        from: 'user_contacts',
                        localField: '_id',
                        foreignField: 'user_id',
                        as: 'contacts'
                    }
                },
                { $unwind: '$role' },
                {
                    $match: conditions
                }
            ];
            if (Object.keys(fields).length) {
                query.push({ $project: fields });
            }
            userModel.aggregate(query)
                .exec(function (err, users) {
                    err ? reject(err) : resolve(self._formatUserData(users));
                });

        });

    },
    getUsersList: function (conditions ={}, fields = {})
    {
       
        return new Promise(function (resolve, reject) {
            var query = userModel.find(conditions);
            if (Object.keys(fields).length) {
                query.select(fields);
            }
            query.exec(function (err, question) {

                err ? reject(err) : resolve(question);
            });
        });
    },
    getUsersByEmail: function (conditions ={}, fields = {})
    {
        return new Promise(function (resolve, reject) {
            var query = userModel.find(conditions);
            if (Object.keys(fields).length) {
                query.select(fields);
            }

            query.exec(function (err, question) {
               
                err ? reject(err) : resolve(question);
            });
        });
    },
    saveUser: function (data) {
        var newUser = new userModel(data);
        newUser.password = bcrypt.hashSync(data.password, config.bcryptSalt);
        return new Promise(function (resolve, reject) {
            newUser.save(function (err, user) {
                err ? reject(err) : resolve(user);
            });
        });
    },
    saveUserContacts: function (conditions, data) {
        console.log(data);
        var newUser = new userContactsModel(data);
      //  newUser.password = bcrypt.hashSync(data.password, config.bcryptSalt);
        return new Promise(function (resolve, reject) {
            newUser.save(function (err, user) {
                err ? reject(err) : resolve(user);
            });
        });
    },
    getUserscontacts: function (conditions = {}, fields = {}, order = {}, limit = 0) {
        
        return new Promise(function (resolve, reject) {
            var query = [
               
                {
                    $lookup: {
                        from: 'users',
                        localField: 'contact_id',
                        foreignField: '_id',
                        as: 'contacts'
                    }
                },
                { $unwind: '$contacts' },
                { $match: conditions }
            ];
            if (Object.keys(fields).length) {
                query.push({ $project: fields });
            }
            if (Object.keys(order).length) {
                query.push({ $sort: order });
            }
            if (limit > 0) {
                query.push({ $limit: limit });
            }
            userContactsModel.aggregate(query)
                .exec(function (err, users) {
                    err ? reject(err) : resolve(users);
                }); 
        });

    },
    
    update: function (conditions, data, upsert = false) {
        return new Promise(function (resolve, reject) {
            userModel.update(conditions,
                { $set: data },
                { upsert },
                function (err, res) {
                    err ? reject(err) : resolve(res);
                })
        });
    },
    updateStatus: function (conditions, data, upsert = false) {
        return new Promise(function (resolve, reject) {
            userModel.update(conditions,
                { $set: data },
                { upsert },
                function (err, res) {
                    err ? reject(err) : resolve(res);
                })
        });
    },
    
    delete: function (conditions) {
        return new Promise(function (resolve, reject) {
            userModel.remove(conditions, function (err) {
                err ? reject(err) : resolve();
            });
        });  
    },
    deleteContacts: function (conditions) {
        return new Promise(function (resolve, reject) {
            userContactsModel.remove(conditions, function (err) {
                err ? reject(err) : resolve();
            });
        });  
    },
    changePassword: function (conditions, data, upsert = false) {
        //console.log(data.password);
        return new Promise(function (resolve, reject) {
             data.password = bcrypt.hashSync(data.password, config.bcryptSalt)
            userModel.update(conditions,
                { $set: data },
                { upsert },
                function (err, res) {
                    err ? reject(err) : resolve(res);
                })
        });
    },
  

    // getSecurityQuestions: function (conditions = {}, fields = {}) {
    //     return new Promise(function (resolve, reject) {
    //         var query = securityModel.find(conditions);
    //         if (Object.keys(fields).length) {
    //             query.select(fields);
    //         }
    //         query.exec(function (err, questions) {
    //             console.log(questions);
    //             err ? reject(err) : resolve(questions);
    //         });
    //     });
    // },
    // getUsers: function (conditions = {}, fields = {}) {
    //     return new Promise(function (resolve, reject) {
    //         var query = testModel.find(conditions);
    //         if (Object.keys(fields).length) {
    //             query.select(fields);
    //         }
    //         query.exec(function (err, questions) {
    //             console.log(questions);
    //             err ? reject(err) : resolve(questions);
    //         });
    //     });
    // },


    _formatUserData: function (users) {
        var resUsers = [];
        users.forEach(function (user, i) {
            resUsers[i] = JSON.parse(JSON.stringify(user));
            delete resUsers[i].role_id;
            if (resUsers[i].role.permissions) {
                var permissionModules = resUsers[i].permission_modules,
                    permissions = resUsers[i].role.permissions.map(function (rp, rpi) {
                        var permission = rp;
                        permissionModules[rpi]['module_id'] = permissionModules[rpi]._id;
                        delete permissionModules[rpi]._id;
                        permissionModules[rpi]['module'] = permissionModules[rpi].name;
                        delete permissionModules[rpi].name;
                        permission = Object.assign({}, permission, permissionModules[rpi]);
                        delete permission.permission_module_id;
                        return permission;
                    });
                delete resUsers[i].role.permissions;
                resUsers[i].role['permissions'] = permissions;
            }
            delete resUsers[i].permission_modules;
        });
        if (!resUsers.length) {
            resUsers = [];
        }
        return resUsers;
    }

 
}