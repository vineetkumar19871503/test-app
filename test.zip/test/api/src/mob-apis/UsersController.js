const bcrypt = require('bcrypt'),
    authHandler = require('../handlers/AuthHandler'),
    generateToken = require('../auth/generateToken'),
    { extractToken } = require('../auth/authorize'),
    userModel = require('../db/models/UserModel'),
securityQuestionModel = require('../db/models/SecurityQuestionModel'),
    nodemailer = require('nodemailer'),
 transporter = nodemailer.createTransport({
    service: 'Gmail',
    auth: {
        user: 'avinesh.mathur@a3logics.in',
        pass: 'Avinesh1233#'
    }
});
objectId = require('mongoose').Types.ObjectId;
    module.exports = {
        name: 'users',
        post: {
            login: function (req, res, next) {

                //  email = req.body.email,
                //     emailid = email.toLowerCase();

                var response = { message: 'User not found!', data: { status: false } };
                var conditions = {};
                
                if (typeof req.body.email != 'undefined' && typeof req.body.password != 'undefined' && typeof req.body.memberId != 'undefined') {
                    conditions.email = req.body.email.toLowerCase();
                    // formCond.password =  req.body.password;
                  //  conditions.memberId = req.body.memberId;
                    const password = req.body.password;
                    userModel.getUsersByEmail(conditions)
                        .then(function (user) {

                            //console.log(user[0]);
                            if (user.length && bcrypt.compareSync(password, user[0].password) && req.body.memberId == user[0].memberId) {
                                user = user[0];

                                generateToken({ id: user._id, email: user.email, name: user.fname }, function (err, token) {
                                  

                                    if (!err) {
                                       // console.log("twrewrsdfsd");
                                        //saving user data into session
                                        req.session.userData = JSON.parse(JSON.stringify(user));
                                        req.session.token = token;

                                        // //preparing response
                                         var resUser = JSON.parse(JSON.stringify(user));
                                        // delete resUser.role.permissions;
                                        response.message = 'Logged in successfully!';
                                        resUser.password = '';
                                        response.data = resUser;
                                        response.data.status = true;
                                        response.token = token;
                                        res.rest.success(response);
                                       //  res.rest.success(response.message = 'Logged in successfully!');
                                    }
                                   
                                    
                                });
                            } else {
                                res.rest.success(response.message = 'Invalid Details!');
                            }
                        })
                        .catch(function (err) {
                            res.rest.serverError(err.message);
                            return next();
                        });


                } else {
                    conditions.memberId = req.body.memberId;

                    userModel.getUsersByEmail(conditions)
                    .then(function (user) {


                        if (user.length) {
                            user = user[0];
                            generateToken({ id: user._id, email: user.email, name: user.fname }, function (err, token) {
                                if (!err) {
                                    //saving user data into session
                                    req.session.userData = JSON.parse(JSON.stringify(user));
                                    req.session.token = token;

                                    //preparing response
                                    var resUser = JSON.parse(JSON.stringify(user));
                                   // delete resUser.role.permissions;
                                    response.message = 'Logged in successfully!';
                                    resUser.password = '';
                                    response.data = resUser;
                                    response.data.status = true;
                                    response.token = token;
                                }
                                res.rest.success(response);
                            });
                        } else {
                            res.rest.success(response);
                        }
                    })
                    .catch(function (err) {
                        res.rest.serverError(err.message);
                        return next();
                    });
                }

            },
            
            register: function (req, res, next) {

                //authHandler(req, res, next, function () {
                    var memberId =  Math.floor(100000 + Math.random() * 900000);
                    const datavalue = {
                        "email": req.body.email,
                        "name": req.body.username,
                        "password": req.body.password,
                        "security_question": req.body.question,
                        "security_answer": req.body.answer,
                        "fname":req.body.fname,
                        "lname":req.body.lname,
                        "status":1,
                        "memberId":memberId
                    }

                   
                    if (typeof req.body.email != 'undefined')
                    {
                       
                        userModel.saveUser(datavalue)
                        .then(function (register) { 
                            message="Hello <b>"+req.body.fname+"</b>,<br><br> You have successfully registered on TWA app. Please use <b>"+memberId+"</b> as TWA Member ID to login.<br><br> Thanks, <br>Team TWA"
                            transporter.sendMail({
                                from: "Twa <noreply@twa.com>", // sender address
                              // to:'avinesh.mathur@a3logics.in', // list of receivers
                                to:req.body.email, // list of receivers
                               subject: "User Registration", // Subject line
                               text: "", // plaintext body
                               html: "<p> "+message+"</p>" // html body
                                });
                            res.rest.success({
                                'data': register,
                                'message': 'User Register successfully!'
                            });
                        })
                        .catch(function (err) {
                            res.rest.serverError({
                                'message': 'Error : User could not be Register! ' + err.message
                            });
                        });
                    }
                    else{
                        res.rest.success({
                            'data': {},
                            'message': 'Invalid Details!'
                        });
                    }
                   
               // });
            },
            changePassword: function (req, res, next) {
                const email = req.body.email,
                    emailid = email.toLowerCase();
                security_question = req.body.security_question;
                security_answer = req.body.security_answer;
                var response = { message: 'User not found!', data: { status: false } };
                if ((email) && (security_question) && (security_answer)) {
                    userModel.getUsersByEmail({ 'email': emailid })
                        .then(function (user) {

                            if (user.length) {
                                user = user[0];
                                if ((user.security_question == security_question) && (user.security_answer == security_answer)) {
                                    response.message = 'Change Password successfully!';
                                    res.rest.success(response);
                                }
                                else {
                                    response.message = 'Securtity Details are Invalid!';
                                    res.rest.success(response);
                                }

                            } else {
                                res.rest.success(response);
                            }
                        })
                        .catch(function (err) {
                            res.rest.serverError(err.message);
                            return next();
                        });
                }
                else {
                    response.message = 'Invalid Inputs';
                    res.rest.success(response);
                }

            },
            saveUserContacts: function (req, res, next) {
                // authHandler(req, res, next, function () {

                let conditions = {};
                userModel.saveUserContacts(conditions, req.body)
                    .then(function (quesitons) {
                        res.rest.success({
                            'data': {},
                            'message': 'Contact added successfully!'
                        });
                    })
                    .catch(function (err) {
                        res.rest.serverError({
                            'message': 'Error : Contact are  not found! ' + err.message
                        });
                    });


                //});

            },
            getContactList: function (req, res, next) {
                // authHandler(req, res, next, function () {
                let conditions = { 'user_id': objectId(req.body.user_id)  };
              // let conditions = {$or:[ {'user_id':objectId(req.body.user_id)}, {'contact_id':objectId(req.body.user_id)} ]};
                userModel.getUserscontacts(conditions)
                    .then(function (Users) {
                        res.rest.success({
                            'data': Users,
                            'message': 'Users list!'
                        });
                    })
                    .catch(function (err) {
                        res.rest.serverError({
                            'message': 'Error : Securtity questions not found! ' + err.message
                        });
                    });

                // });
            },
            removeContact: function (req, res, next) {
                // authHandler(req, res, next, function () {
                let conditions = { 
                    'user_id': objectId(req.body.user_id),
                     'contact_id': objectId(req.body.contact_id)  

                     };
              // let conditions = {$or:[ {'user_id':objectId(req.body.user_id)}, {'contact_id':objectId(req.body.user_id)} ]};
               userModel.deleteContacts(conditions, req.body)
                .then(function (users) {
                    res.rest.success({
                        'data': {},
                        'message': 'Contact removed successfully!'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : Contact could not be removed! ' + err.message
                    });
                });

                // });
            }

        },
        get: {
            logout: function (req, res, next) {
                // if header token is matches the session token then destroy the session
                //if (req.session.token === extractToken(req)) {
                req.session.destroy(function (err) {
                    if (err) {
                        res.rest.serverError(err.message);
                    } else {
                        res.rest.success('Logged out successfully!');
                    }
                });
                // } else {
                //     res.rest.unauthorized('You are not authorized to perform this action.');
                // }
            },
            getSecurityQuestions: function (req, res, next) {

                // authHandler(req, res, next, function () {

                let conditions = {};
                securityQuestionModel.getSecurityQuestion(conditions)
                    .then(function (quesitons) {
                        res.rest.success({
                            'data': quesitons,
                            'message': 'Securtity questions!'
                        });
                    })
                    .catch(function (err) {
                        res.rest.serverError({
                            'message': 'Error : Securtity questions not found! ' + err.message
                        });
                    });


                //});

            },
            list: function (req, res, next) {
                // authHandler(req, res, next, function () {
                let conditions = { 'status': 1 };
                userModel.getUsers(conditions)
                    .then(function (Users) {
                        res.rest.success({
                            'data': Users,
                            'message': 'Users list!'
                        });
                    })
                    .catch(function (err) {
                        res.rest.serverError({
                            'message': 'Error : Securtity questions not found! ' + err.message
                        });
                    });

                // });
            },

        }
    }