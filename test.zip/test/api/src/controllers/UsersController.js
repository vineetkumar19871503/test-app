const bcrypt = require('bcrypt'),
    authHandler = require('../handlers/AuthHandler'),
    generateToken = require('../auth/generateToken'),
    { extractToken } = require('../auth/authorize'),
    userModel = require('../db/models/UserModel');
var nodemailer = require('nodemailer');  
var transporter = nodemailer.createTransport({
    service: 'Gmail',
    auth: {
        user: 'avinesh.mathur@a3logics.in',
        pass: 'Avinesh1233#'
    }
});

module.exports = {
    name: 'users',
    post: {
        login: function (req, res, next) {
            //  var saltRounds = 10;
            // var salt = bcrypt.genSaltSync(saltRounds);
            //        var hash = bcrypt.hashSync('654321', salt);
            //         console.log(hash, 'hashhashhashhash');

            const email = req.body.email,
                emailid = email.toLowerCase();
            password = req.body.password;
            var response = { message: 'User not found!', data: {} };
            userModel.getUsers({ 'email': emailid })
                .then(function (user) {


                    if (user.length && bcrypt.compareSync(password, user[0].password)) {
                        user = user[0];
                        generateToken({ id: user._id, email: user.email, name: user.fname }, function (err, token) {
                            if (!err) {
                                //saving user data into session
                                req.session.userData = JSON.parse(JSON.stringify(user));
                                req.session.token = token;

                                //preparing response
                                var resUser = JSON.parse(JSON.stringify(user));
                                delete resUser.role.permissions;
                                response.message = 'Logged in successfully!';
                                resUser.password = '';
                                response.data = resUser;
                                response.token = token;
                            }
                            res.rest.success(response);
                        });
                    } else {
                        res.rest.success(response);
                    }
                })
                .catch(function (err) {
                    res.rest.serverError(err.message);
                    return next();
                });
        },
        add: function (req, res, next) {
            // authHandler(req, res, next, function () {
            const datavalue = {
                "email": req.body.email,
                "name": req.body.name,
                "password": req.body.password,
                "security_question": req.body.security_question,
                "security_answer": req.body.security_answer,
            }

            userModel.saveUser(datavalue)
                .then(function (register) {
                    res.rest.success({
                        'data': register,
                        'message': 'User Register successfully!'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : User could not be Register! ' + err.message
                    });
                });
            // });
        },

        edit: function (req, res, next) {
            // authHandler(req, res, next, function () {
            console.log(req.body);
            userModel.update({ '_id': req.body.id }, req.body)
                .then(function (users) {
                    res.rest.success({
                        'data': users,
                        'message': 'User Update successfully!'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : User could not be Updated! ' + err.message
                    });
                });
            //});
        },
        delete: function (req, res, next) {
            //  authHandler(req, res, next, function () {
            userModel.delete({ '_id': req.body.id }, req.body)
                .then(function (users) {
                    res.rest.success({
                        'data': users,
                        'message': 'User Delete successfully!'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : User could not be Delete! ' + err.message
                    });
                });

            //});
        },
        getUserById: function (req, res, next) {

            //  authHandler(req, res, next, function () {

            userModel.getUsersByEmail({ '_id': req.body.id })
                .then(function (users) {
                    res.rest.success({
                        'data': users,
                        'message': 'User Delete successfully!'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : User could not be Delete! ' + err.message
                    });
                });

            //});
        },
        updateStatus: function (req, res, next) {
            // authHandler(req, res, next, function () {
            // console.log( req.body);
            userModel.updateStatus({ '_id': req.body.id }, req.body)
                .then(function (users) {
                    res.rest.success({
                        'data': users,
                        'message': 'User Update successfully!'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : User could not be Updated! ' + err.message
                    });
                });
            //});
        },
        updateStatus: function (req, res, next) {
            // authHandler(req, res, next, function () {
            console.log(req.body);
            userModel.updateStatus({ '_id': req.body.id }, req.body)
                .then(function (users) {
                    res.rest.success({
                        'data': users,
                        'message': 'User Update successfully!'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : User could not be Updated! ' + err.message
                    });
                });
            //});
        },
        sendMail: function (req, res, next) {
            var msg = req.body.msg;
            console.log(msg);
            userModel.getUsersByEmail({ '_id': req.body.id })
                .then(function (users) {

                    transporter.sendMail({
                        from: "Twa <noreply@twa.com>", // sender address
                        to: "avinesh.mathur@a3logics.in", // list of receivers
                        subject: "User list", // Subject line
                        text: "", // plaintext body
                        html: "<p> " + msg + "</p>" // html body
                    });

                    res.rest.success({
                        'data': users,
                        'message': 'Send Mail Successfully'
                    });
                    console.log(users);
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : User could not be Updated! ' + err.message
                    });
                });




            //  transporter.sendMail({
            //    from: "Twa <noreply@twa.com>", // sender address
            //    to:"avinesh.mathur@a3logics.in", // list of receivers
            //   subject: "User list", // Subject line
            //   text: "", // plaintext body
            //   html: "<p> Hello Test</p>" // html body
            //    });

            // res.send({
            //   "status": "success",
            //   "data": null,
            //   "message": "Please check your mail for new password"
            // });

        },

        changePassword: function (req, res, next) {
            console.log(req.body);
            oldPassword = req.body.oldpassword;
            var response = { message: 'User not found!', data: {},tostermsg:'error' };
            userModel.getUsersByEmail({ '_id': req.body.id })
                .then(function (users) {
                    console.log(users);
                    if (users.length && bcrypt.compareSync(oldPassword, users[0].password)) {

                        // response.message = 'Logged in successfully!';
                        // res.rest.success(response);
                         const datavalue = {
                "password": req.body.newpassword,
            }

                          userModel.changePassword({ '_id': req.body.id }, datavalue)
                   .then(function (users) {
                       res.rest.success({
                           'data': {},
                           'message': 'Change Password successfully!'
                       });
                   })
                   .catch(function (err) {
                       res.rest.serverError({
                           'message': 'Error : Password not be Changed! ' + err.message
                       });
                   });
                    }
                    else {
                        res.rest.success(response);
                    }

                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : Password not be Changed! ' + err.message
                    });
                });

            // userModel.changePassword({ '_id': req.body.id }, req.body)
            //        .then(function (users) {
            //            res.rest.success({
            //                'data': users,
            //                'message': 'Change Password successfully!'
            //            });
            //        })
            //        .catch(function (err) {
            //            res.rest.serverError({
            //                'message': 'Error : Password not be Changed! ' + err.message
            //            });
            //        });

        }
    },
    get: {
        logout: function (req, res, next) {
            // if header token is matches the session token then destroy the session
            //if (req.session.token === extractToken(req)) {
            req.session.destroy(function (err) {
                if (err) {
                    res.rest.serverError(err.message);
                } else {
                    res.rest.success('Logged out successfully!');
                }
            });
            // } else {
            //     res.rest.unauthorized('You are not authorized to perform this action.');
            // }
        },
        list: function (req, res, next) {
            // authHandler(req, res, next, function () {
            let conditions = {};
            userModel.getUsersList(conditions)
                .then(function (Users) {
                    res.rest.success({
                        'data': Users,
                        'message': 'Users list!'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : Users not found! ' + err.message
                    });
                });

            // });
        },

        getSecurityQuestions: function (req, res, next) {

            // authHandler(req, res, next, function () {

            let conditions = {};
            securityQuestionModel.getSecurityQuestion(conditions)
                .then(function (quesitons) {
                    res.rest.success({
                        'data': quesitons,
                        'message': 'Securtity questions!'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : Securtity questions not found! ' + err.message
                    });
                });


            //});

        },

    }
}