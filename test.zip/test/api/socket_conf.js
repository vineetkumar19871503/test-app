const geodist = require('geodist');
var emailsWithSocketIds = {},
    userLocations = {},
    roomParticipants = [];

function socketIdsInRoom(io, roomId, cb) {
    io.in(roomId).clients((err, clients) => {
        cb(clients);
    });
}

function parseCoords(coords) {
    let res = {};
    for (var key in coords) {
        if (coords.hasOwnProperty(key)) {
            res[key] = parseFloat(parseFloat(coords[key]).toFixed(4));
        }
    }
    return res;
}

function getUserBySocketId(sId) {
    for (var email in emailsWithSocketIds) {
        if (emailsWithSocketIds.hasOwnProperty(email)) {
            if (emailsWithSocketIds[email].socketId === sId)
                return emailsWithSocketIds[email];
        }
    }
}

module.exports = function (server) {
    const io = require('socket.io')(server, {
        pingTimeout: 30000,
        pingInterval: 30000
    });
    io.on('connection', function (socket) {
        socket.on('disconnect', function () {
            const user = getUserBySocketId(socket.id);
            if (user) {
                delete emailsWithSocketIds[user.email];
                delete userLocations[user.email];
            }
            if (socket.room) {
                var room = socket.room;
                io.to(room).emit('leave', socket.id);
                socket.leave(room);
            }
        });

        socket.on('join', function (joinData, callback) { //Join room
            const roomId = joinData.roomId,
                email = joinData.email,
                joineeData = emailsWithSocketIds[email];
            socket.join(roomId);
            socket.room = roomId;
            const socketIds = socketIdsInRoom(io, roomId, function (socketIds) {
                roomParticipants = socketIds.map((socketId) => {
                    let participant;
                    for (var e_mail in emailsWithSocketIds) {
                        if (emailsWithSocketIds.hasOwnProperty(e_mail)) {
                            if (socketId == emailsWithSocketIds[e_mail].socketId) {
                                participant = emailsWithSocketIds[e_mail];
                                break;
                            }
                        }
                    }
                    return { socketId, participant };
                }).filter((participant) => participant.socketId != socket.id);
                callback(roomParticipants);
                roomParticipants.forEach((participant) => {
                    io.sockets.clients().connected[participant.socketId].emit("on_participant_joined", roomId, joineeData);
                });
            });
        });


        socket.on("count", function (roomId, callback) {
            if (roomId) {
                var socketIds = socketIdsInRoom(io, roomId, function (socketIds) {
                    callback(socketIds.length);
                });
            } else {
                callback(io.engine.clientsCount);
            }
        });

        socket.on('leave_room', function (data) {
            const roomId = data.room_id;
            socket.leave(roomId);
            io.sockets.in(roomId).emit('participant_left', { user: emailsWithSocketIds[data.email] });
        });
        socket.on('drop_call', function (data) {
            // if we found data.to then this is one-to-one call and we need to tell the other user that we are leaving
            if (data.drop_inform_to) {
                const toUser = emailsWithSocketIds[data.drop_inform_to.email];
                if (toUser) {
                    const to = io.sockets.clients().connected[toUser.socketId];
                    data.dropped_by.socketId = socket.id;
                    to.emit('participant_dropped_call', data.dropped_by);
                }
            } else {
                io.to(data.room_id).emit('participant_dropped_call', data.dropped_by);
            }
        });

        socket.on('exchange', function (data) {
            // console.log('exchange', data);
            data.from = socket.id;
            var to = io.sockets.clients().connected[data.to];
            if (to) {
                to.emit('exchange', data);
            }
        });

        socket.on('line_busy', function (data) {
            const toSocketId = emailsWithSocketIds[data.to.email].socketId;
            if (toSocketId) {
                const to = io.sockets.clients().connected[toSocketId];
                to.emit('participant_busy', data);
            }
        });
        socket.on('mapUserWithSocketId', function (data, cb) {
            //if (!emailsWithSocketIds[data.user.email]) {
            data.user.socketId = socket.id;
            emailsWithSocketIds[data.user.email] = data.user;
            let locationFound = false;
            if (data.user.location) {
                let p = Object.assign({}, data.user.location.position);
                p.lon = p.lng;
                delete p.lng;
                userLocations[data.user.email] = p;
                console.log(userLocations);
                locationFound = true;
            }
            if (typeof cb == 'function') {
                cb(locationFound);
            }
            //}
            // console.log('obj after mapping: \n\n\n\n\n\n\n');
            // console.log(emailsWithSocketIds);
            // console.log('obj after mapping: \n\n\n\n\n\n\n');
        });

        socket.on('outgoing_call', function (data) {
            const _p = emailsWithSocketIds,
                toUser = _p[data.to.email],
                fromUser = _p[data.from.email];
            if (toUser && fromUser) {
                data.to.socketId = toUser.socketId;
                data.from.socketId = fromUser.socketId;
                const to = io.sockets.clients().connected[toUser.socketId];
                to.emit('incoming_call', data);
            } else {
                if (!toUser) {
                    io.sockets.clients().connected[fromUser.socketId].emit('not_reachable');
                }
            }
        });

        socket.on('reject_call', function (rejectData) {
            const toSocketId = emailsWithSocketIds[rejectData.rejectedOf.email].socketId;
            if (toSocketId) {
                const to = io.sockets.clients().connected[toSocketId];
                to.emit('participant_rejected_call', rejectData.rejecter);
            }
        });

        socket.on('test_socket_mapping', function (cb) {
            cb(emailsWithSocketIds);
        });

        socket.on('user_logout', function () {
            const user = getUserBySocketId(socket.id);
            if (user) {
                delete emailsWithSocketIds[user.email];
                delete userLocations[user.email];
            }
            if (socket.room) {
                var room = socket.room;
                io.to(room).emit('leave', socket.id);
                socket.leave(room);
            }
        });

        socket.on('get_users_by_coords', function (data, cb) {
            let users = [];
            for (var email in userLocations) {
                if (email != data.email && userLocations.hasOwnProperty(email)) {
                    const coords = Object.assign({}, data.coords);
                    coords.lon = coords.lng;
                    delete coords.lng;
                    const dist = geodist(parseCoords(coords), parseCoords(userLocations[email]));
                    console.log(dist);
                    if (dist <= data.radius) {
                        users.push(emailsWithSocketIds[email]);
                    }
                }
            }
            cb(users);
        });
    });
}