/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View
} from 'react-native';

const services = require('./socket/services');

// importing redux and middlewares
import { compose, createStore, applyMiddleware } from 'redux';
import { createLogger } from 'redux-logger';
import { Provider } from 'react-redux';
import thunkMiddleware from 'redux-thunk';

import rootReducer from './reducers/';

// importing initial components
import Layout from './components/Layout';
import Drawer from './routes/drawer';
import Routes from './routes/routes';

// creating redux store
const store = createStore(
  rootReducer,
  { services },
  compose(applyMiddleware(thunkMiddleware)
  )
);
export default class App extends Component {
  render() {
    return (
      <Provider store={store}>
        <Layout>
          <Drawer />
        </Layout>
      </Provider>
    );
  }
}

