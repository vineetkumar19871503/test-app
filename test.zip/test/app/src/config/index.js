import { Dimensions } from 'react-native';
const window = Dimensions.get('window');
export default {
  conferenceName: 'twa_conference',
  // socketServerUrl: 'https://oney-webrtc-server.herokuapp.com',
  socketServerUrl: 'https://twaapi.herokuapp.com',
  screenWidth: window.width,
  screenHeight: window.height,
  thumbnailHeight: 60,
  thumbnailWidth: 60,
  useRCTView: true, //debug or not?
  video: {
    minWidth: 500,
    minHeight: 300,
    minFrameRate: 30
  }
}