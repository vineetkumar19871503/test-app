import React, { Component } from 'react';
import {
  AsyncStorage, Button, Text, View, StyleSheet, ImageBackground, TouchableOpacity, TouchableHighlight
} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import { showPopup } from '../actions/LayoutAction';
import { NavigationActions } from 'react-navigation';
import { connect } from 'react-redux';
import { logout } from '../actions/UserAction';

class Header extends React.Component {

  constructor(props) {
    super(props);
    this.state = { menuPopUp: false };
    this.logout = this.logout.bind(this);
  }

  backPressed = () => {
    // alert('121');
    const navigateAction = NavigationActions.navigate({
      routeName: 'Home'
    });
    // this.props.navigation.dispatch(navigateAction);
    this.props.navigation.goBack();
    return true;
  }

  logout() {
    const _p = this.props;
    _p.services.logout();
    AsyncStorage.removeItem('localUserInfo');
    _p.logout();
    _p.nav.navigate('Login');
  }

  render() {
    const showPopup = this.props.layout.showPopup;
    return (
      <View>
        <View style={styles.header}>
          <View style={{ flex: 1 }}>
            <Icon
              name="arrow-left"
              onPress={() => this.props.nav.goBack(null)}
              style={{ color: '#fff', paddingRight: 10, width: 20 }}
              size={30}
            />
          </View>
          <View style={{ flex: 1, alignItems: 'center' }}>
            <Text style={{ color: '#fff' }}>{this.props.headerTitle}</Text>
          </View>

          <View style={{ flex: 1, alignItems: 'flex-end' }}>
            <Icon
              name="ellipsis-v"
              style={{ color: '#fff', paddingRight: 10, width: 20 }}
              onPress={() => this.props.showPopup(!showPopup)}
              size={30}
            />
          </View>
        </View>
        {
          showPopup ?
            <TouchableHighlight onPress={this.logout} ref="header-menu" style={{ flex: 1, position: 'absolute', elevation: 11, backgroundColor: '#fff', right: 20, top: 40 }}>
              <Text style={styles.navItemStyle} >Logout</Text>
            </TouchableHighlight>
            : null
        }
      </View>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    services: state.services,
    user: state.users,
    layout: state.layout
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    logout: () => dispatch(logout()),
    showPopup: (isShowPopup) => dispatch(showPopup(isShowPopup))
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Header);

const styles = StyleSheet.create({
  header: {
    height: 50,
    backgroundColor: '#242e42',
    padding: 10,
    alignSelf: 'stretch',
    // flex:1,
    flexDirection: 'row',
  },
  navItemStyle: {
    color: '#000',
    padding: 10,
    fontSize: 20,
    borderBottomWidth: 1,
    borderColor: '#171819'
  },
});

// export default Header