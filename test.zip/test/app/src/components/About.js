import React, { Component } from 'react';
import {
  Button, Text, View, StyleSheet, ImageBackground, AsyncStorage
} from 'react-native';
import { connect } from 'react-redux';
import { FormLabel, FormInput } from 'react-native-elements';
import Icon from 'react-native-vector-icons/FontAwesome';
import LinearGradient from 'react-native-linear-gradient';
import Loader from './Loader';
class About extends React.Component {
  static navigationOptions = {
    title: 'About',
  };

  constructor(props) {
    super(props);
    this.state = { loading: true };
  }

  componentWillMount() {
    // AsyncStorage.removeItem('email');
    AsyncStorage.getItem('email').then((value) => {
      if (value) {
        this.setState({ loader: false, logged: true, email: value })
      } else {
        this.setState({ loader: false })
      }
    })
  }
  testSocket() {
    this.props.services.testSocketMapping();
  }
  render() {
    return (
      <View style={styles.container}>
      <LinearGradient colors={['#444', '#242e42', '#000']} style={styles.linearGradient}>
      <View style={styles.outerDiv}>

        <View style={{flexDirection:'column'}}>
          {/* <View style={styles.header}>
            <Text style={{fontWeight:'bold'}}> Contact </Text>
          </View> */}
          <Text style={{ fontWeight: 'bold', fontSize: 20 }} > Kollel Ohr Haemet </Text>
          <Text>112 Steamboat Rd {"\n"}
            Great Neck, NY 11024{"\n"}
          
              Phone: (516)487-6080{"\n"}
          
              Fax:  (516)888-6080{"\n"}
          
              Email: info@greatneckkollel.org{"\n"}
          
              Web: greatneckkollel.org{"\n"}
          
          
       </Text>
       </View>
       </View>
        <View style={styles.DivTwoCol}>
          <View sstyle={{flex:0.5,width:50, borderWidth:1}}>
              <Text  > To Join Our Mailing List <Text style={{ color: 'blue', textDecorationLine: 'underline' }}>click here</Text> </Text>
            </View>
            <View sstyle={{flex:0.5,width:50, borderWidth:1}}>
              <Text style={{ fontWeight: 'bold', flex:0.5,fontSize: 20 }} > To Donate <Text style={{ color: 'blue', textDecorationLine: 'underline' }}>click here</Text> </Text>
          </View>
        </View>
        <View style={styles.outerDiv}>

        <View style={{alignSelf: 'stretch', flexDirection:'column' }}>
          <Text style={{ fontSize: 15 }} > Useful links:</Text>
          <Text style={{ fontSize: 15 }} > Kollel printer friendly Minyan schedule <Text style={{ color: 'blue', textDecorationLine: 'underline' }}>click here</Text> </Text>
          <Text style={{ fontSize: 15 }} > Great Neck Zmanim <Text style={{ color: 'blue', textDecorationLine: 'underline' }}>click here</Text> </Text>
        </View>
        <View style={{backgroundColor: '#DDDDDD',padding: 5,}}>
          <Text style={{ fontSize: 15 }} > Published by <Text style={{ color: 'blue', textDecorationLine: 'underline' }}>Google Drive</Text>
           --
           <Text style={{ color: 'blue', textDecorationLine: 'underline' }}>Report Abuse</Text>
           --
           Updated automatically wvery 5 minutes
            </Text>
      </View>
      </View>
        </LinearGradient>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  linearGradient: {
    flex: 1,
    paddingTop: 20,
    paddingBottom: 10,
  },
  container: {
    flex: 1,
    // flexDirection: 'column',
    // alignItems: 'stretch',
    // justifyContent: 'center',
  },
  outerDiv:{
    backgroundColor: '#fff',
    margin:5,
    padding:5,
    borderRadius:10,
    flex:1
  },
  DivTwoCol: {
    backgroundColor: '#fff',
    margin:5,
    padding:5,
    borderRadius:10,
    flex:1,
    flexDirection:'row'
  },
  header: {
    height: 50, backgroundColor: '#DDDDDD',
    padding: 10, alignSelf: 'stretch',
  },
  innerContent: {
    flexDirection: 'row',
  },
  textHead: {
    lineHeight: 25,
    fontSize: 15,
    fontWeight: 'bold',
  },
  textValue: {
    lineHeight: 25,
    fontSize: 15,
  }
});

const mapStateToProps = (state) => {
  return {
    services: state.services
  }
}
export default connect(mapStateToProps)(About);