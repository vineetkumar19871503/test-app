import React, { Component } from 'react';
import {
  Button, Text, View, StyleSheet, PermissionsAndroid, Modal, Alert
} from 'react-native';
import { connect } from 'react-redux';
import { FormLabel, FormInput } from 'react-native-elements';
import Geocoder from 'react-native-geocoder';
import Icon from 'react-native-vector-icons/FontAwesome';
import Loader from './Loader';
import RNAndroidLocationEnabler from 'react-native-android-location-enabler';
import { updateLocation } from '../actions/UserAction';
import Geolocation from 'react-native-geolocation-service';
class LocationMessage extends React.Component {

  constructor(props) {
    super(props);
    this.state = { loading: false, locationMsg: false };
  }

  closeLocationModal() {
    this.setState({ locationMsg: false });
    this.getDeviceLocation();
  }

  //ask for location popup
  async getDeviceLocation() {
    const self = this,
      chckLocationPermission = PermissionsAndroid.check(PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION);
    if (chckLocationPermission === PermissionsAndroid.RESULTS.GRANTED) {
      alert("You've access for the location");
    } else {
      try {
        const granted = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
          // {
          //     'title': 'Cool Location App required Location permission',
          //     'message': 'We required Location permission in order to get device location ' +
          //         'Please grant us.'
          // }
        )
        if (granted === PermissionsAndroid.RESULTS.GRANTED) {
          self.setState({ loading: true });
          RNAndroidLocationEnabler.promptForEnableLocationIfNeeded({
            interval: 10000,
            fastInterval: 5000
          })
            .then(data => {
              self.getGeoLocation();
            })
            .catch(err => {
              // The user has not accepted to enable the location services or something went wrong during the process
              // "err" : { "code" : "ERR00|ERR01|ERR02", "message" : "message"}
              // codes : 
              //  - ERR00 : The user has clicked on Cancel button in the popup
              //  - ERR01 : If the Settings change are unavailable
              //  - ERR02 : If the popup has failed to open
            });
        } else {
          this.setState({ locationMsg: true });
        }
      } catch (err) {
        alert(err)
      }
    }
  }

  getGeoLocation() {
    const self = this;
    Geolocation.getCurrentPosition(
      (position) => {
        Geocoder.geocodePosition({
          lat: position.coords.latitude,
          lng: position.coords.longitude
        })
          .then(res => {
            self.setState({ loading: false });
            self.props.updateLocation(res[0]);
          })
          .catch(err => {
            self.setState({ loading: false });
            Alert.alert('', 'Your GPS location could not be fetched. Retrying...');
            self.getGeoLocation();
          })
      },
      (error) => {
        // See error code charts below.
        Alert.alert('', error.message);
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 }
    );
  }

  componentDidMount() {
    this.getDeviceLocation();
  }
  componentWillUnmount() {
    navigator.geolocation.clearWatch(this.watchID);
  }

  render() {
    return (
      <View >
        <Loader loading={this.state.loading} message="Getting your location..." />
        {
          (this.state.locationMsg) ?
            <Modal
              animationType="slide"
              transparent={false}
              visible={this.state.locationMsg}
              onRequestClose={() => {
                alert('Modal has been closed.');
              }}
            >
              <View style={{
                flex: 1,
                backgroundColor: 'black',
                flexDirection: 'column',
                justifyContent: 'center',
                alignItems: 'center'
              }}>
                <Text style={{ color: 'white', flexDirection: 'row', paddingBottom: 150 }}>Location is required to continue</Text>
                <Text onPress={() => this.closeLocationModal()} style={{ color: 'blue' }}>click here</Text>
              </View>
            </Modal>
            : null
        }
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
  }
});

const mapStateToProps = (state) => {
  return {};
}

const mapDispatchToProps = (dispatch) => {
  return {
    updateLocation: location => dispatch(updateLocation(location))
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(LocationMessage);