import React, { Component } from 'react';
import {
  Button, StyleSheet, Text, View, Image, TouchableHighlight, BackHandler, ScrollView,
  Platform, TextInput, KeyboardAvoidingView, TouchableOpacity, Alert, AsyncStorage, Picker
} from 'react-native';
import axios from 'axios';
import { connect } from 'react-redux';
import { FormLabel, FormInput } from 'react-native-elements';
import Icon from 'react-native-vector-icons/FontAwesome';
import Loader from './Loader';
import { login } from '../actions/UserAction';
import logo from '../../image/logo.png';
import { NavigationActions } from 'react-navigation';
import t from 'tcomb-form-native';
import LinearGradient from 'react-native-linear-gradient';
import _ from 'lodash';
const Form = t.form.Form;
const stylesheet = _.cloneDeep(t.form.Form.stylesheet);
stylesheet.textbox.normal.color = '#00FF00';
stylesheet.pickerContainer.normal = {
  borderColor: '#cccccc',
  marginTop:0,
  color:'#00a',
  borderColor:'#ccc',
  borderWidth:1,
  borderRadius:2,
  padding:0
};
stylesheet.pickerContainer.open = {
  color: '#a00',

};

class ForgotPassword extends React.Component {
  // static navigationOptions = {
  //   title: '',
  //   headerMode: null
  // }; 

  constructor(props) {
    super(props)
    const self = this;
    self.state = { loading: true, value: {} };
    self._onPress = self._onPress.bind(self);

    //set form options
    this.options = {
      fields: {
        email: {
          label: 'What is your e-mail address?',
        },
        question: {
          label: 'What is your security question?',
          nullOption: { value: '', text: 'Select Questions' },
          stylesheet: stylesheet
        },
        answer: {
          label: 'What is your answer?',
        },
      },
    };

    //set form
    self.ForgotPasswordForm = t.struct({
      email: t.String,
      question: t.enums({}),
      answer: t.String
    });

    //call api for security questions
    axios.get('https://twa-apis.herokuapp.com/api/v1.0/users/getSecurityQuestions')
      .then(function (response) {
        self.setState({
          loading: false
        });
        if (response.data.data) {
          var singleObj = {};
          let users = response.data.data.filter((usr) => {
            singleObj[usr._id] = usr.question;
            return singleObj;
          });

          // patching values from api
          self.ForgotPasswordForm = t.struct({
            email: t.String,
            question: t.enums(
              singleObj
            ),
            answer: t.String
          });
          self.setState({ 'securityQuestions': singleObj });
        } else {
          Alert.alert(
            '',
            response.data.message,
          );
        }
      })
      .catch(function (error) {
        self.setState({
          loading: false
        });
      });
  }

  componentWillMount() {
    BackHandler.addEventListener('hardwareBackPress', this.backPressed);
  }

  componentWillUnmount() {
    BackHandler.removeEventListener('hardwareBackPress', this.backPressed);
  }

  backPressed = () => {
    const navigateAction = NavigationActions.navigate({
      routeName: 'Login'
    });
    this.props.navigation.dispatch(navigateAction);
    return true;
  }

  _onPress = () => {
    const self = this;
    // // call getValue() to get the values of the form
    var value = self.refs.form.getValue();
    // if (value) { // if validation fails, value will be null
    //   self.setState({
    //     loading: true
    //   });
    //   axios.post('https://twa-apis.herokuapp.com/api/v1.0/users/login', {
    //     email: value.email,
    //     question: value.answer
    //     answer: value.answer
    //   })
    //     .then(function (response) {
    //       self.setState({
    //         loading: false
    //       });
    //       if (response.data.data.status) {
    //         self.props.login(response.data.data);
    //         self.props.services.mapUserWithSocketId(response.data.data);
    //         self.props.navigation.navigate('UsersListing');
    //       } else {
    //         Alert.alert(
    //           '',
    //           response.data.message,
    //         );
    //      }
    //     })
    //     .catch(function (error) {
    //       self.setState({
    //         loading: false
    //       });
    //     });
    // }
  }

  onChangeForm = (value) => {
    this.setState({ value });
  }

  clearForm() {
    // clear content from all textbox
    this.setState({ value: null });
  }
  render() {

    return (
      <ScrollView keyboardShouldPersistTaps='always'>
        <LinearGradient colors={['#000', '#fff']} style={styles.linearGradient}>
          <Loader loading={this.state.loading} />
          {/* <KeyboardAvoidingView style={styles.container} behavior="padding"> */}
          {/* <View style={{ height: 30 }} /> */}
          <View style={styles.container} >
            <Form ref="form"
              onChange={this.onChangeForm}
              value={this.state.value}
              options={this.options}
              type={this.ForgotPasswordForm} />
            
            {/* <View style={{ height: 100 }} /> */}
            {/* </KeyboardAvoidingView> */}
          </View>
          <TouchableHighlight style={styles.button} onPress={this._onPress} underlayColor='#99d9f4'>
              <Text style={styles.buttonText}>Submit</Text>
            </TouchableHighlight>
            <View style={styles.textBlcok} >
            </View>
        </LinearGradient>
      </ScrollView>
    );
  }
}


const mapStateToProps = (state) => {
  return {
    services: state.services
  }
}

export default connect(mapStateToProps)(ForgotPassword);

const styles = StyleSheet.create({
  linearGradient: {
    flex: 1,
    padding:10,
  

  },
  container: {
    justifyContent: 'center',
    marginTop: 0,
    padding: 20,
    backgroundColor: '#eaeaea',
    flex: 1,
    borderRadius:10
    // borderWidth: 0,
    // alignSelf: 'center',,styles.dystyle]
    // alignItems: 'stretch',
    // justifyContent: 'center',
    // flexDirection: 'column',
  },
  buttonText: {
    fontSize: 18,
    color: 'white',
    alignSelf: 'center'
  },
  button: {
    paddingTop: 15,
    paddingBottom: 15,
    backgroundColor: '#000000',
    borderWidth: 0,
    borderRadius: 50,
    marginBottom: 10,
    marginTop: 10,
    borderRadius: 100,
    alignSelf: 'stretch',
    justifyContent: 'center',

  },
  textBlcok: {
    flex: 1,
    flexDirection: 'row',
    alignSelf: 'center',
  },
});
