import React, { Component } from 'react';
import {
    Button, Text, View, StyleSheet, TouchableHighlight
} from 'react-native';
import { connect } from 'react-redux';
import { FormLabel, FormInput } from 'react-native-elements';
import FullScreenVideo from "./FullScreenVideo.js";
import Icon from 'react-native-vector-icons/FontAwesome';
import Loader from './Loader';
import LoudSpeaker from 'react-native-loud-speaker';
import styles from '../../style/app';
import Thumbnails from "./Thumbnails.js";

class Conference extends React.Component {
    static navigationOptions = {
        title: 'Conference'
    };

    constructor(props) {
        super(props);
        this.state = { loading: true };
        this.dropCall = this.dropCall.bind(this);
        this.state = {
            activeStreamUrl: null,
            audioMuted: false,
            callbacks: {
                participantStreamAdded: this.participantStreamAdded.bind(this)
            },
            isFrontCamera: true,
            joined: false,
            participants: [],
            roomId: 'xyzabc',
            selfStream: null,
            socketIO: null,
            streams: [],
            videoMsg: null
        }
    }

    componentWillMount() {
        this.setState({ socketIO: this.props.services.getSocket() });
    }

    async componentDidMount() {
        const self = this;
        await this._getLocalStream();
        this.bindSocketEvents();
        this.props.services.bindComponentCallbacksToServices(this.state.callbacks);
        // join the room
        self.props.services.join(self.state.roomId, self.props.user.email, function (participants) {
            self.setState({ joined: true });
        });
    }

    dropCall() {
        const params = { 'dropped_by': this.props.user, 'room_id': this.state.roomId };
        this.setState({ activeStreamUrl: null, streams: [] });
        this.props.services.dropCall(params);
        this._resetCall();
    }

    addParticipant(participant) {
        const participants = this.state.participants;
        participants.push(participant);
        this.setState({ participants });
    }

    bindSocketEvents() {
        const socket = this.state.socketIO,
            self = this;

        // bind events when socket is connected
        socket.on('connect', function (data) {

            // when any participant joins a room
            socket.on("on_participant_joined", function (roomId, participant) {
                self._addParticipant(participant);
            });
            socket.on('participant_dropped_call', function (droppedBy) {
                alert('participant_dropped_call');
                // self.onParticipantDroppedCall(droppedBy);
            });
            socket.on('participant_left', function (data) {
                alert('participant_left');
                // todo: remove participant from participants array
                // self.onParticipantLeft(data);
            });
        });
    }

    killStream(socketId = null) {
        const streams = this.state.streams;
        for (let str = 0; str < streams.length; str++) {
            if (streams[str].socketId == socketId) {
                this.props.services.destroyPeerConnection(socketId, streams[str].streamObj);
                streams.splice(str, 1);
                break;
            }
        }
        this.setState({ streams });
    }

    participantStreamAdded(socketId, stream) {
        const self = this;
        let streams = this.state.streams,
            newState = {},
            _sUrl = stream.toURL();
        // if its a one-to-one call and the first participant joins then show him on full screen
        if (streams.length == 1 && this.props.call.callType == 'call') {
            newState.activeStreamUrl = _sUrl;
        }
        // filter existing stream by socket id
        streams = streams.filter(function (str) {
            return str.socketId != socketId;
        });
        streams.push({
            socketId,
            streamObj: stream,
            url: _sUrl
        });
        newState.streams = streams;
        this.setState(newState);
        setTimeout(function () {
            self._loudSpeaker(true);
        }, 100);
    }


    _getLocalStream() {
        const self = this,
            _st = self.state;
        // getting the client's steam and setting it into state
        self.props.services.getLocalStream(self.state.isFrontCamera, (stream) => {
            const _sU = stream.toURL(),
                streams = _st.streams;
            streams.push({
                socketId: _st.socketIO.id,
                streamObj: stream,
                url: _sU
            });
            self.setState({
                selfStream: stream,
                activeStreamUrl: _sU,
                streams: streams
            });
        });
    }

    _getSocketIdOfParticipant(participant) {
        let socketId = null,
            _p = this.state.participants;
        for (let p = 0; p < _p.length; p++) {
            if (_p[p].email == participant.email) {
                socketId = _p[p].socketId;
                break;
            }
        }
        return socketId;
    }

    _loudSpeaker(status = true) {
        LoudSpeaker.open(status);
    }

    _muteUnmuteAudio(mute = true) {
        const _ss = this.state.selfStream;
        if (_ss) {
            this.setState({ 'audioMuted': mute });
            _ss.getAudioTracks()[0].enabled = mute ? false : true;
        }
    }
    _muteUnmuteVideo(mute = true) {
        const _ss = this.state.selfStream;
        if (_ss) {
            let msg = mute ? 'Video is muted...' : null;
            this.setState({ 'videoMuted': mute, 'videoMsg': msg });
            _ss.getVideoTracks()[0].enabled = mute ? false : true;
        }
    }

    // mute both audio and video
    _muteMedia(mute = true) {
        this._muteUnmuteAudio(mute);
        this._muteUnmuteVideo(mute);
    }

    _resetCall() {
        this.setState({
            'activeStreamUrl': this.state.selfStream.toURL(),
            'joined': false
        });
        this._loudSpeaker(false);
    }

    render() {
        return (
            <View>
                {this.state.joined
                    ?
                    <View style={{ backgroundColor: '#000' }}>
                        <Text style={styles.videoMsg}>{this.state.videoMsg}</Text>
                        <FullScreenVideo streamURL={this.state.activeStreamUrl} />
                        <View style={styles.callOptions}>
                            <Icon
                                style={styles.callOptIcon}
                                onPress={() => this._muteUnmuteAudio(!this.state.audioMuted)}
                                name={this.state.audioMuted ? 'microphone-slash' : 'microphone'}
                                size={28}
                                color="#fff" />
                            <TouchableHighlight
                                style={styles.dropButton}
                                onPress={this.dropCall} >
                                <Icon
                                    name="phone"
                                    size={25}
                                    color="#fff" />
                            </TouchableHighlight>
                            <Icon
                                style={styles.callOptIcon}
                                onPress={() => this._muteUnmuteVideo(!this.state.videoMuted)}
                                name={this.state.videoMuted ? 'video-camera' : 'video-camera'}
                                size={28}
                                color="#fff" />
                        </View>
                        <Thumbnails streams={this.state.streams}
                            setActive={(streamUrl) => this.setState({ 'activeStreamUrl': streamUrl })}
                            activeStreamUrl={this.state.activeStreamUrl} />
                    </View>
                    :
                    null
                }
            </View>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        call: state.call,
        services: state.services,
        user: state.users
    }
}

export default connect(mapStateToProps)(Conference);