import React, { Component } from 'react';
import {
  Alert, AppRegistry, SectionList, Platform, Button, StyleSheet, Text, View, Image, TextInput, TouchableHighlight,
  TouchableOpacity, TouchableNativeFeedback, TouchableWithoutFeedback, ListView, ScrollView, KeyboardAvoidingView,
  BackHandler, Picker
} from 'react-native';
import Loader from './Loader';
import axios from 'axios';
import profileImage from '../../image/user-default-profile.png';
import { connect } from 'react-redux';
import { NavigationActions } from 'react-navigation';
import Footer from './Footer';
import Geocoder from 'react-native-geocoder';

class UsersListingScreen extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      contactList: new ListView.DataSource({
        rowHasChanged: (row1, row2) => row1 !== row2,
      }),
      dataSource: new ListView.DataSource({
        rowHasChanged: (row1, row2) => row1 !== row2,
      }),
      errorMsg: null,
      initialPosition: 'unknown',
      loading: true,
      radius: 0,
      usersLoaded: false
    }
  }
  static navigationOptions = {
    title: 'Users Listing',
    cardStyle: { backgroundColor: 'black' }
  };

  //get current location
  // _getDeviceLocation() {
  // this.setState({ initialPosition: this.props.user.location.formattedAddress });

  // navigator.geolocation.getCurrentPosition(
  //   (position) => {
  //     // const initialPosition = JSON.stringify(position);
  //     // Position Geocoding
  //     var coords = {
  //       lat: position.coords.latitude,
  //       lng: position.coords.longitude
  //     };

  //     Geocoder.geocodePosition(coords).then(res => {
  //       const initialPosition = res[0].formattedAddress;
  //       this.setState({ initialPosition });
  //     })
  //       .catch(err => console.log(err))
  //   },
  //   (error) => {
  //     alert(error.message)
  //   },
  //   // { enableHighAccuracy: true, timeout: 20000, maximumAge: 10000 }
  // );
  // this.watchID = navigator.geolocation.watchPosition((position) => {
  //   const lastPosition = JSON.stringify(position);
  //   this.setState({ lastPosition });
  // });
  // }

  componentDidMount() {
    const self = this;
    self.setState({
      initialPosition: this.props.user.location.formattedAddress
    });

    axios.post('https://twaapi.herokuapp.com/api/v1.0/users/getContactList', { 'user_id': self.props.user._id })
      .then(function (response) {
        // extract myself from users list
        self.setState({ loading: false, usersLoaded: true, contactList: response.data.data });
        self.filterUsersList(response.data.data, 'contacts');
      })
      .catch(function (error) {
        self.setState({ loading: false });
      });

    // axios.get('https://twaapi.herokuapp.com/api/v1.0/users/list')
    //   .then(function (response) {
    //     // extract myself from users list
    //     self.setState({ loading: false, usersLoaded: true, contactList: response.data.data });
    //     self.filterUsersList(response.data.data);
    //   })
    //   .catch(function (error) {
    //     self.setState({
    //       loading: false
    //     });
    //   });
  }

  componentWillMount() {
    BackHandler.addEventListener('hardwareBackPress', this.backPressed);
  }

  componentWillUnmount() {
    BackHandler.removeEventListener('hardwareBackPress', this.backPressed);
  }

  backPressed = () => {
    return;
    const navigateAction = NavigationActions.navigate({
      routeName: 'Home'
    });
    this.props.navigation.dispatch(navigateAction);
    // this.props.navigation.goBack();
    return true;
  }

  filterUsersList(users, listType) {
    const self = this;
    let msg = null;
    if (!users.length) {
      msg = listType == 'contacts' ? 'No contacts available' : 'No nearby users available';
    }
    users = users.filter((usr) => usr.email != self.props.user.email);
    self.setState({ dataSource: users, errorMsg: msg });
  }

  goToProfilePage(user) {
    this.props.navigation.navigate('UserDetail', user);
  }

  getUsersInRange(radius) {
    const self = this;
    self.setState({ radius });
    const _u = self.props.user;
    if (radius <= 0) {
      self.filterUsersList(this.state.contactList, 'contacts');
    } else {
      this.props.services.getUsersByArea(radius, _u.email, _u.location.position, function (users) {
        self.filterUsersList(users, 'users');
      });
    }
  }

  _keyExtractor = (item, index) => index.toString();

  render() {
    console.log(this.state.dataSource);
    return (
      <View style={{ flex: 1 }}>
        <View style={{ flex: 0.7 }}>
          <Loader loading={this.state.loading} />

          <View style={styles.addressBar}>
            <Text style={{ justifyContent: 'center', alignSelf: 'center' }}>
              {this.state.initialPosition}
            </Text>
          </View>
          <View style={styles.radiusSelect}>
            <Picker
              selectedValue={this.state.radius}
              onValueChange={(value, index) => this.getUsersInRange(value)}
            >
              <Picker.Item label="Select Radius" value={0} />
              <Picker.Item label="5 Miles" value="5" />
              <Picker.Item label="10 Miles" value="10" />
            </Picker>
          </View>
          <View style={styles.container}>
            {this.state.dataSource.length ?
              <ScrollView keyboardShouldPersistTaps="always">
                {this.state.dataSource.map((item, i) =>
                  <TouchableHighlight key={i} onPress={() => this.goToProfilePage(item)} username style={styles.singlelist}>
                    <View style={{ flexDirection: 'row' }}>
                      <View style={styles.imageContainer}>
                        <Image source={profileImage} style={styles.profileImage} />
                      </View>
                      <View style={{
                        marginLeft: 10,
                        flex: 1,
                        flexDirection: 'column',
                        alignItems: 'flex-start',
                        justifyContent: 'center'
                      }}>
                        <Text style={{ fontSize: 18, color: '#434b52', fontWeight: '300' }}>{item.name}</Text>
                        <Text style={{ fontSize: 14, color: '#ccc', }}>{item.email}</Text>
                      </View>
                    </View>
                  </TouchableHighlight>
                )}
              </ScrollView>
              : null}
            {this.state.errorMsg ?
              <View style={{ padding: 10 }}><Text style={{ color: 'red' }}>{this.state.errorMsg}</Text></View>
              : null
            }
          </View>
        </View>
        <Footer />
      </View>
    );
  }
}

var styles = StyleSheet.create({

  container: {
    // flex:1,
    justifyContent: 'center',
    padding: 0,
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#ddd',
    borderBottomWidth: 0,
    shadowColor: '#000',
    shadowOffset: { width: 5, height: 5 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 10,
    marginLeft: 5,
    marginRight: 5,
    marginTop: 10,
    borderRadius: 5,
    // alignSelf: 'stretch',
  },
  addressBar: {
    // flex:1,
    justifyContent: 'center',
    padding: 10,
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#ddd',
    borderBottomWidth: 0,
    shadowColor: '#000',
    shadowOffset: { width: 1, height: 1 },
    shadowOpacity: 0.3,
    shadowRadius: 1,
    elevation: 1,
    marginLeft: 0,
    marginRight: 0,
    marginTop: 0,
    // borderRadius: 20,
    // alignSelf: 'stretch',
  },
  radiusSelect: {
    // flex:1,
    justifyContent: 'center',
    padding: 3,
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#ddd',
    borderBottomWidth: 0,
    shadowColor: '#000',
    shadowOffset: { width: 2, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 20,
    elevation: 5,
    marginLeft: 5,
    marginRight: 5,
    marginTop: 5,
    borderRadius: 5,
    height: 40
    // alignSelf: 'stretch',
  },
  title: {
    fontSize: 30,
    alignSelf: 'center',
    marginBottom: 30
  },
  buttonText: {
    fontSize: 18,
    color: 'white',
    alignSelf: 'center'
  },
  button: {
    height: 36,
    backgroundColor: '#48BBEC',
    borderColor: '#48BBEC',
    borderWidth: 1,
    borderRadius: 8,
    marginBottom: 10,
    alignSelf: 'stretch',
    justifyContent: 'center'
  },
  imageContainer: {
    width: 42,
    height: 42,
    borderRadius: 60,
    backgroundColor: '#fff',
    borderRadius: 100,
    borderWidth: 5,
    borderColor: '#eaeaea',
  },
  profileImage: {
    width: 22,
    height: 22,
    alignSelf: 'center',
    marginTop: 5


  },
  singlelist: {
    borderRadius: 5,
    padding: 10,
    backgroundColor: '#fff',
    marginBottom: 0,
    marginLeft: 0,
    marginRight: 0,
    marginTop: 0,
    borderBottomWidth: 1,
    borderColor: '#eaeaea'
  }
});

const mapStateToProps = (state) => {
  return {
    services: state.services,
    user: state.users
  }
}
export default connect(mapStateToProps)(UsersListingScreen);