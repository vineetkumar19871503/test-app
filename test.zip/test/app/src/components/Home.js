import React, { Component } from 'react';
import {
  Button, Text, View, StyleSheet, ImageBackground, AsyncStorage, Image, PermissionsAndroid
} from 'react-native';
import { connect } from 'react-redux';
import Loader from './Loader';
import profileImage from '../../image/user-default-profile.png';
import RNAndroidLocationEnabler from 'react-native-android-location-enabler';
import Geocoder from 'react-native-geocoder';
class Home extends React.Component {
  static navigationOptions = {
    title: 'Home',
  };

  constructor(props) {
    super(props);
    this.state = {
      loading: true,
      initialPosition: 'unknown',
      lastPosition: 'unknown',
    };
    this.testSocket = this.testSocket.bind(this);
  }


  // componentDidMount = () => {
  //   // this._getDeviceLocation();
  // }

  componentWillUnmount = () => {
    // navigator.geolocation.clearWatch(this.watchID);
  }

  //get current location
  _getDeviceLocation() {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        // const initialPosition = JSON.stringify(position);
        // Position Geocoding
        var cord = {
          lat: position.coords.latitude,
          lng: position.coords.longitude
        };

        Geocoder.geocodePosition(cord).then(res => {
          const initialPosition = res[0].formattedAddress;
          this.setState({ initialPosition });
        })
          .catch(err => console.log(err))
      },
      (error) => {
        alert(error.message)
      },
      // { enableHighAccuracy: true, timeout: 20000, maximumAge: 10000 }
    );
    // this.watchID = navigator.geolocation.watchPosition((position) => {
    //   const lastPosition = JSON.stringify(position);
    //   this.setState({ lastPosition });
    // });
  }

  componentWillMount() {
    this._getDeviceLocation();
    // AsyncStorage.removeItem('email');
    AsyncStorage.getItem('email').then((value) => {
      if (value) {
        this.setState({ loader: false, logged: true, email: value })
      } else {
        this.setState({ loader: false })
      }
    })
  }
  testSocket() {
    this.props.services.testSocketMapping();
  }
  render() {
    return (
      <View style={styles.container}>

        <View style={styles.profileSection}>
          <View style={styles.imageContainer}>
            <Image source={profileImage} style={styles.profileImage} />
          </View>
          <View style={styles.profileName}>
            <Text style={{ color: '#fff', fontWeight: 'bold', }}>
              Name
            </Text>
            <Text style={{ color: 'red' }}>
              (LEO)
            </Text>
          </View>

        </View>
        <View style={styles.detailSection}>
          <Text>
            {this.state.initialPosition}
          </Text>

          <Text style={styles.boldText}>
            Current position:
            </Text>

          <Text>
            {this.state.lastPosition}
          </Text>
        </View>
      </View >
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'stretch',
    justifyContent: 'center',
  },
  profileSection: {
    flex: .4,
    backgroundColor: 'grey',
    justifyContent: 'center',
    flexDirection: 'column',
  },
  detailSection: {
    flex: .6,
    backgroundColor: '#fff',
  },
  imageContainer: {
    width: 110,
    height: 110,
    borderRadius: 90,
    backgroundColor: '#fff',
    borderColor: '#ccc',
    borderWidth: 6,
    alignSelf: 'center',
  },
  profileImage: {
    width: 90,
    height: 90,
    alignSelf: 'center',
    paddingTop: 10
  },
  profileName: {
    // height: 30,
    alignSelf: 'center',
    paddingTop: 5,
  },




  image: {
    flexGrow: 1,
    height: null,
    width: null,
    alignItems: 'center',
    justifyContent: 'center',
  },
  paragraph: {
    color: '#fff',
    textAlign: 'center',
  },
});

const mapStateToProps = (state) => {
  return {
    services: state.services
  }
}
export default connect(mapStateToProps)(Home);