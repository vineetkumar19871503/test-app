import React, { Component } from 'react';
import t from 'tcomb-form-native';
import {
  Alert,
  BackHandler,
  Button,
  StyleSheet,
  keyboardShouldPersistTaps,
  KeyboardAvoidingView,
  Picker,
  ScrollView,
  Text,
  TextInput,
  TouchableHighlight,
  TouchableOpacity,
  View
} from 'react-native';

import Icon from 'react-native-vector-icons/FontAwesome';
import { NavigationActions } from 'react-navigation';
import axios from 'axios';
import Header from './Header.js';
import Loader from './Loader';

const Form = t.form.Form;


// const questions = t.enums({
//   name: '',
//   mname: ''
// }, 'questions');


function customQuestionTemplate(locals) {
  var error =
    locals.hasError && locals.error ? (
      <Text accessibilityLiveRegion="polite" style={{ flex: 1, color: '#a00' }}>
        {locals.error}
      </Text>
    ) : null;

  return (
    <View>
      <View style={styles.inputSection}>
        <Icon style={styles.inputIcon} name="key" size={20} color="#000" />
        <Picker
          style={styles.inputForm}
          selectedValue={locals.value}
          onValueChange={locals.onChange}
        >
          <Picker.Item label="SECUERITY QUESTION" />
          <Picker.Item label="Your Name222" value="name" />
          <Picker.Item label="Your Mother Name" value="mname" />

        </Picker>
      </View>
      {error}
    </View>
  );
}

class Registration extends React.Component {
  static navigationOptions = {
    title: 'Registration',
  };
  constructor(props) {
    super(props)
    const self = this;
    this.state = { loading: true, value: {} };
    this.state.headerTitle = 'New User';

    this._onPress = this._onPress.bind(this);

    //set form options
    this.options = {
      fields: {
        fname: {
          label: 'FIRST NAME',
          help: 'user',
          // error: 'username required!',
          template: customFieldsTemplate
        },
        lname: {
          label: 'LAST NAME',
          help: 'user',
          // error: 'username required!',
          template: customFieldsTemplate
        },
        username: {
          label: 'USERNAME',
          help: 'user',
          // error: 'username required!',
          template: customFieldsTemplate
        },
        email: {
          label: 'EMAIL',
          help: 'at',
          // error: 'email required!',
          template: customFieldsTemplate
        },
        password: {
          label: 'PASSWORD',
          help: 'lock',
          password: true,
          secureTextEntry: true,
          // error: 'password required!',
          template: customFieldsTemplate
        },
        re_password: {
          label: 'RE-PASSWORD',
          help: 'lock',
          password: true,
          secureTextEntry: true,
          // error: 'password required!',
          template: customFieldsTemplate
        },
        question: {
          auto: 'none',
          // label: 'Question',
          nullOption: { value: '', text: 'Select Questions' },
          // template: customQuestionTemplate,
          // error: 'question required!',
        },
        answer: {
          label: 'ANSWER',
          help: 'unlock',
          // error: 'answer required!',
          template: customFieldsTemplate
        }
      }
    };

    //set form
    self.User = t.struct({
      // fname: fName,
      // lname: lName,
      // username: userName,
      // email: Email,
      // password: Password,
      // re_password: rePassword,
      // question: t.enums({}),
      // answer: Answer
    });

    //call api for security questions
    axios.get('https://twa-apis.herokuapp.com/api/v1.0/users/getSecurityQuestions')
      .then(function (response) {
        self.setState({
          loading: false
        });
        if (response.data.data) {

          var singleObj = {};
          let users = response.data.data.filter((usr) => {
            singleObj[usr._id] = usr.question;
            return singleObj;
          });
          // patching values from api
          //set form
          self.User = t.struct({
            fname: fName,
            lname: lName,
            username: userName,
            email: Email,
            password: Password,
            re_password: rePassword,
            question: t.enums(
              singleObj
            ),
            answer: Answer
          });
          self.setState({ 'securityQuestions': singleObj });
        } else {
          Alert.alert(
            '',
            response.data.message,
          );
        }
      })
      .catch(function (error) {
        self.setState({
          loading: false
        });
      });

    function customFieldsTemplate(locals) {
      var error =
        locals.hasError && locals.error ? (
          <Text accessibilityLiveRegion="polite" style={{ flex: 1, color: '#a00' }}>
            {locals.error}
          </Text>
        ) : null;
      console.log(locals);
      if (locals.label == "PASSWORD" || locals.label == "RE-PASSWORD") {
        var secureTextEntry = true;
      }

      return (
        <View>
          <View style={styles.inputSection}>
            <Icon style={styles.inputIcon} name={locals.help} size={20} color="#000" />
            <TextInput
              style={styles.inputForm}
              placeholder={locals.label}
              // value={locals.value}
              onChangeText={value => locals.onChange(value)}
              secureTextEntry={secureTextEntry}
              // onChange={locals.onChangeNative}
              // onChangeText={(searchString) => { this.setState({ searchString }) }}
              underlineColorAndroid="transparent"
            />
          </View>
          {error}
        </View>
      );
    }

    //username validation
    var userName = t.refinement(t.String, val => this.requiredField(val));
    userName.getValidationErrorMessage = val => {
      if (!this.requiredField(val)) {
        return 'username required!';
      }
    };

    //fname validation
    var fName = t.refinement(t.String, val => this.requiredField(val));
    fName.getValidationErrorMessage = val => {
      if (!this.requiredField(val)) {
        return 'first name required!';
      }
    };

    //lname validation
    var lName = t.refinement(t.String, val => this.requiredField(val));
    lName.getValidationErrorMessage = val => {
      if (!this.requiredField(val)) {
        return 'last name required!';
      }
    };

    //question validation
    var questions = t.refinement(t.String, val => this.requiredField(val));
    questions.getValidationErrorMessage = val => {
      if (!this.requiredField(val)) {
        return 'questions required!';
      }
    };

    //email validation
    var Email = t.refinement(t.String, val => this.requiredField(val) && this.validEmail(val));
    Email.getValidationErrorMessage = val => {
      if (!this.requiredField(val)) {
        return 'email required!';
      }
      else if (!this.validEmail(val)) {
        return 'Invalid email address';
      }
    };

    //password validation
    var Password = t.refinement(t.String, val => this.requiredField(val));
    Password.getValidationErrorMessage = val => {
      if (!this.requiredField(val)) {
        return 'password required!';
      }
    };

    //confirm password validation
    var rePassword = t.refinement(t.String, val => this.requiredField(val) && this.matchPassword(val));
    rePassword.getValidationErrorMessage = val => {
      if (!this.requiredField(val)) {
        return 'confirm password required!';
      }
      else if (!this.matchPassword(val)) {
        return 'password don\'t match';
      }
    };

    //Answer validation
    var Answer = t.refinement(t.String, val => this.requiredField(val));
    Answer.getValidationErrorMessage = val => {
      if (!this.requiredField(val)) {
        return 'answer required!';
      }
    };

  }

  //required field check
  requiredField = (val) => {
    if (val) {
      return true;
    } else {
      return false;
    }
  }

  //valid email check 
  validEmail = (val) => {
    const reg = /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/; //or any other regexp
    const checkEmailValid = reg.test(val);
    if (checkEmailValid) {
      return true;
    } else {
      return false;
    }
  }

  //match confirm password check 
  matchPassword = (val) => {
    return val == this.state.value.password;
  }

  componentWillMount() {
    BackHandler.addEventListener('hardwareBackPress', this.backPressed);
  }

  componentWillUnmount() {
    BackHandler.removeEventListener('hardwareBackPress', this.backPressed);
  }

  backPressed = () => {
    const navigateAction = NavigationActions.navigate({
      routeName: 'Home'
    });
    this.props.navigation.dispatch(navigateAction);
    return true;
  }

  _onPress = () => {
    const self = this;
    this.setState({
      loading: true
    });

    // call getValue() to get the values of the form
    var value = this.refs.form.getValue();
    //for clear the form after success
    // this.clearForm();
    if (value) { // if validation fails, value will be null
      delete value.re_password;
      var formValue = JSON.stringify(value);
      axios.post('https://twaapi.herokuapp.com/api/v1.0/users/register',
        {
          "fname": value.fname,
          "lname": value.lname,
          "username": value.username,
          "email": value.email,
          "password": value.password,
          "question": value.question,
          "answer": value.answer,
        }
      )
        .then(async function (response) {
          self.setState({
            loading: false
          });
          if (response.status == 200) {
            await Alert.alert(
              '',
              'Registration successful! Please check your email.',
              [{ text: 'OK', onPress: () => self.props.navigation.navigate('Login') }]
            );
          } else {
            Alert.alert('', 'Registration failed!');
          }
        })
        .catch(function (error) {
          self.setState({
            loading: false
          });
        });

    } else {
      this.setState({
        loading: false,
      });
    }
  }

  onChangeForm = (value) => {
    this.setState({ value });
  }

  clearForm() {
    // clear content from all textbox
    this.setState({ value: null });
  }

  render() {

    return (
      <ScrollView keyboardShouldPersistTaps='always' >
        <Loader loading={this.state.loading} />
        <View style={styles.container} >
          <Form ref="form"
            options={this.options}
            value={this.state.value}
            onChange={this.onChangeForm}
            type={this.User} />
          <TouchableHighlight style={styles.button} onPress={this._onPress} underlayColor='#99d9f4'>
            <Text style={styles.buttonText}>Register</Text>
          </TouchableHighlight>
        </View>
      </ScrollView>

    );
  }
}

var styles = StyleSheet.create({
  container: {
    justifyContent: 'center',
    marginTop: 5,
    padding: 20,
    backgroundColor: '#ffffff',
  },
  title: {
    fontSize: 30,
    alignSelf: 'center',
    marginBottom: 30
  },
  buttonText: {
    fontSize: 18,
    color: 'white',
    alignSelf: 'center',

  },
  button: {
    height: 36,
    backgroundColor: '#48BBEC',
    borderColor: '#48BBEC',
    borderWidth: 1,
    borderRadius: 8,
    marginBottom: 10,
    marginTop: 10,
    alignSelf: 'stretch',
    justifyContent: 'center'
  },
  inputForm: {
    flex: 1,
    paddingTop: 10,
    paddingRight: 10,
    paddingBottom: 10,
    paddingLeft: 0,
    //backgroundColor: '#fff',
    color: '#000',
    borderWidth: 0,
  },
  inputSection: {
    borderBottomColor: '#bbb',
    borderBottomWidth: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  inputIcon: {
    padding: 10,
  }
});

export default Registration