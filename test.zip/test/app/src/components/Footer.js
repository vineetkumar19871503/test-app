import React, { Component } from 'react';
import {
  Button, Text, View, StyleSheet, ImageBackground, TouchableOpacity, TouchableHighlight, Dimensions
} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import IconMaterial from 'react-native-vector-icons/MaterialCommunityIcons';
import { showPopup } from '../actions/LayoutAction';
import { NavigationActions } from 'react-navigation';
import { connect } from 'react-redux';
import { logout } from '../actions/UserAction';
var { width, height } = Dimensions.get('window')

class Footer extends React.Component {

  constructor(props) {
    super(props);
  }

  backPressed = () => {
    // alert('121');
    const navigateAction = NavigationActions.navigate({
      routeName: 'Home'
    });
    // this.props.navigation.dispatch(navigateAction);
    this.props.navigation.goBack();
    return true;
  }

  render() {
    const showPopup = this.props.layout.showPopup;
    return (
      <View style={{ position:'absolute', padding:10, bottom:0, flex:1,flexDirection:'row', elevation: 11,backgroundColor: '#242e42'}}>
      {/* <View style={{ top: 55, backgroundColor: '#242e42', height: 40, flexDirection: 'row' }}> */}
        <View style={{ flex: 0.5, alignItems: 'center', justifyContent: 'center' }}>
          <Text><IconMaterial name="map-marker-outline" size={20} color="#fff" /></Text>
        </View>
        <View style={{ flex: 0.5, alignItems: 'center', justifyContent: 'center' }}>
          <Text><Icon name="video-camera" size={20} color="#fff" /></Text>
        </View>
      </View>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    services: state.services,
    user: state.users,
    layout: state.layout
  }
}

const mapDispatchToProps = (dispatch) => {
  return {}
}

export default connect(mapStateToProps, mapDispatchToProps)(Footer);

