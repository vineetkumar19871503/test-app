import React, { Component } from 'react';
import {
  Button, StyleSheet, Text, View, Image, TouchableHighlight, BackHandler, ScrollView,
  Platform, TextInput, KeyboardAvoidingView, TouchableOpacity, Alert, AsyncStorage, NativeModules
} from 'react-native';
import axios from 'axios';
import { connect } from 'react-redux';
import { FormLabel, FormInput } from 'react-native-elements';
import Icon from 'react-native-vector-icons/FontAwesome';
import Loader from './Loader';
import { login } from '../actions/UserAction';
import logo from '../../image/logo.png';
import { NavigationActions } from 'react-navigation';
import t from 'tcomb-form-native';
import LinearGradient from 'react-native-linear-gradient';
const Form = t.form.Form;

class Login extends React.Component {
  static navigationOptions = {
    title: '',
    headerMode: null
  };

  constructor(props) {
    super(props)
    this.state = { loading: false, localUserInfo: null, memberIdErrorMsg:null, isMemberId: false, memberId:null, value: { 'email': 'john@twa.com', 'password': '12345678' } };
    // this.state = { loading: false, localUserInfo: null, memberIdErrorMsg: null, isMemberId: false, memberId: null, value: {} };
    this._onPress = this._onPress.bind(this);
    //email validation
    var Email = t.refinement(t.String, val => this.requiredField(val) && this.validEmail(val));
    Email.getValidationErrorMessage = val => {
      if (!this.requiredField(val)) {
        return 'email required!';
      }
      else if (!this.validEmail(val)) {
        return 'Invalid email address';
      }
    };

    //password validation
    var Password = t.refinement(t.String, val => this.requiredField(val));
    Password.getValidationErrorMessage = val => {
      if (!this.requiredField(val)) {
        return 'password required!';
      }
    };

    //set form
    this.UserLogin = t.struct({
      email: Email,
      password: Password,
    });
  }

  //required field check
  requiredField = (val) => {
    if (val) {
      return true;
    } else {
      return false;
    }
  }

  //valid email check 
  validEmail = (val) => {
    const reg = /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/; //or any other regexp
    const checkEmailValid = reg.test(val);
    if (checkEmailValid) {
      return true;
    } else {
      return false;
    }
  }

  async componentWillMount() {
    let localUserInfo = await AsyncStorage.getItem('localUserInfo');
    if (localUserInfo) {
      localUserInfo = JSON.parse(localUserInfo);
      this.setState({ localUserInfo, isMemberId: true });
    }
    BackHandler.addEventListener('hardwareBackPress', this.backPressed);
  }

  componentWillUnmount() {
    BackHandler.removeEventListener('hardwareBackPress', this.backPressed);
  }

  backPressed = () => {
    const navigateAction = NavigationActions.navigate({
      routeName: 'UsersListing'
    });
    this.props.navigation.dispatch(navigateAction);
    // this.props.navigation.goBack();
    return true;
  }

  _loginSubmit = () => {
    const self = this;
    var value = self.refs.form.getValue();
    if (value) {
      this.setState({ isMemberId: true });
    }
  }

  async _onPress() {
    const self = this;
    self.setState({ memberIdErrorMsg: '' })
    const formValueObj = {};
    if (self.state.memberId) {
      const usr = self.state.localUserInfo;
      if (usr) {
        if (self.state.memberId == usr.memberId) {
          await self.props.login(usr);
          self.props.services.mapUserWithSocketId(usr);
          self.props.navigation.navigate('UsersListing');
          // formValueObj.memberId = self.state.memberId;
        } else {
          self.setState({ memberIdErrorMsg: 'Invalid member ID' });
        }
      } else {
        // call api if local member id doesn't exist
        var value = self.state.value;
        formValueObj.email = value.email;
        formValueObj.password = value.password;
        formValueObj.memberId = self.state.memberId;
        if (value) { // if validation fails, value will be null
          self.setState({
            loading: true
          });
          axios.post('https://twaapi.herokuapp.com/api/v1.0/users/login',
            formValueObj
          )
            .then(async function (response) {
              self.setState({
                loading: false
              });
              if (response.data.data.status) {
                const userInfo = Object.assign({}, response.data.data, { memberId: self.state.memberId });
                await self.props.login(userInfo);
                self.props.services.mapUserWithSocketId(self.props.user);
                AsyncStorage.setItem('localUserInfo', JSON.stringify(self.props.user));
                self.props.navigation.navigate('UsersListing');
              } else {
                self.setState({ isMemberId: false })
                Alert.alert(
                  '',
                  response.data.message,
                );
              }
            })
            .catch(function (error) {
              self.setState({
                loading: false
              });
            });
        }
      }
    } else {
      self.setState({ memberIdErrorMsg: 'This field is required' });
    }


    // if (!self.state.memberId) {
    //   self.setState({ memberIdErrorMsg: 'This field is required' })
    // } else if (self.state.localMemberId) {
    //   if(self.state.memberId == self.state.localMemberId) {
    //     formValueObj.memberId = self.state.memberId;  
    //   } else {
    //     self.setState({ memberIdErrorMsg: 'Invalid member ID' })  
    //   }
    // } else {
    //   formValueObj.email = value.email;
    //   formValueObj.password = value.password;
    //   formValueObj.memberId = self.state.memberId;
    //   var value = self.state.value;
    //   if (value) { // if validation fails, value will be null
    //     self.setState({
    //       loading: true
    //     });
    //     axios.post('https://twa-apis.herokuapp.com/api/v1.0/users/login',
    //       formValueObj
    //     )
    //       .then(function (response) {
    //         self.setState({
    //           loading: false
    //         });
    //         if (response.data.data.status) {
    //           const userInfo = Object.assign({}, response.data.data, self.state.memberId);
    //           AsyncStorage.setItem('localMemberId', self.state.memberId);
    //           AsyncStorage.setItem('localUserInfo', self.state.memberId);
    //           self.props.login(response.data.data);
    //           self.props.services.mapUserWithSocketId(self.props.user);
    //           self.props.navigation.navigate('UsersListing');
    //         } else {
    //           Alert.alert(
    //             '',
    //             response.data.message,
    //           );
    //         }
    //       })
    //       .catch(function (error) {
    //         self.setState({
    //           loading: false
    //         });
    //       });
    //   }
    // }

  }

  customFieldsTemplate = (locals) => {
    var error =
      locals.hasError && locals.error ? (
        <Text accessibilityLiveRegion="polite" style={{ flex: 1, color: '#a00' }}>
          {locals.error}
        </Text>
      ) : null;

    if (locals.label == 'PASSWORD') {
      var submitArrow = null;
      var secureTextEntry = true;
      var dystyle = 'forEmail';
    } else {
      var submitArrow = null;
      var secureTextEntry = null;
      var dystyle = 'forPass';
    }

    return (
      <View>
        <View style={styles.inputSection}>
          <Icon style={styles.inputIcon} name={locals.help} size={20} color="#000" />
          <TextInput
            style={styles.inputForm}
            placeholder={locals.label}
            secureTextEntry={secureTextEntry}
            onChangeText={value => locals.onChange(value)}
            underlineColorAndroid="transparent"
          />
          {submitArrow}
        </View>
        {error}
      </View>
    );
  }

  onChangeForm = (value) => {
    this.setState({ value });
  }

  onChangeMemberId = (text) => {
    this.setState({ 'memberId': text });
  }

  clearForm() {
    // clear content from all textbox
    this.setState({ value: null });
  }

  render() {
    //set form options
    this.options = {
      fields: {
        email: {
          label: 'EMAIL',
          help: 'at',
          template: this.customFieldsTemplate
        },
        password: {
          label: 'PASSWORD',
          password: true,
          secureTextEntry: true,
          help: 'lock',
          template: this.customFieldsTemplate
        },
      },
    };

    return (
      <View style={{ flex: 1 }}>
        <Loader loading={this.state.loading} />
        {
          this.state.isMemberId
            ?
            <View style={{ flex: 1 }}>
              <View style={{ flex: 0.9, alignSelf: 'stretch', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
                <Text style={{ fontWeight: 'bold' }}>Please enter TWA Member ID</Text>
                <TextInput
                  underlineColorAndroid={'transparent'}
                  style={{ height: 40, width: 180, borderBottomColor: '#000', borderBottomWidth: 1 }}
                  placeholder="TWA Member ID"
                  // onChangeText={(memberId) => this.setState({ memberId })}
                  onChangeText={(text) => this.onChangeMemberId(text)}
                />
                <Text style={{ color: '#ed1c25' }}>{this.state.memberIdErrorMsg}</Text>
              </View>
              <View style={{ flex: 0.1, alignSelf: 'stretch', alignItems: 'center', justifyContent: 'center' }}>
                <TouchableHighlight style={{ backgroundColor: '#242e42', alignSelf: 'stretch', justifyContent: 'center', paddingTop: 15, paddingBottom: 15, }}
                  onPress={this._onPress} underlayColor='#99d9f4'>
                  <Text style={styles.buttonText}>Confirm</Text>
                </TouchableHighlight>
              </View>
            </View>
            :
            <ScrollView keyboardShouldPersistTaps='always'>
              <LinearGradient colors={['#fff', '#ccc']} style={styles.linearGradient}>
                {/* <KeyboardAvoidingView style={styles.container} behavior="padding"> */}
                {/* <View style={{ height: 30 }} /> */}
                <View style={styles.container} >
                  <Image source={logo} style={{ width: 100, height: 166, alignSelf: 'center' }} />
                  <Text style={styles.title}>THIRD WITNESS</Text>
                  <Form ref="form"
                    onChange={this.onChangeForm}
                    value={this.state.value}
                    options={this.options}
                    type={this.UserLogin} />
                  <TouchableHighlight style={styles.button} onPress={this._loginSubmit} underlayColor='#99d9f4'>
                    <Text style={styles.buttonText}>LOGIN</Text>
                  </TouchableHighlight>
                  <View style={styles.textBlcok} >
                    <Text onPress={() => {
                      this.props.navigation.navigate('Registration');
                    }} style={styles.newText}>
                      New User
                    </Text>
                    <Text style={styles.newText}>|</Text>
                    <Text onPress={() => {
                      this.props.navigation.navigate('ForgotPassword');
                    }} style={styles.newText}>Forgot Password</Text>

                  </View>
                  {/* <View style={{ height: 100 }} /> */}
                  {/* </KeyboardAvoidingView> */}
                </View>
              </LinearGradient>
            </ScrollView>
        }
      </View>
    );
  }
}


const mapStateToProps = (state) => {
  return {
    services: state.services,
    user: state.users
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    login: (userData) => dispatch(login(userData))
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Login);

const styles = StyleSheet.create({
  linearGradient: {
    flex: 1,
    paddingTop: 20,
    paddingBottom: 10,

  },
  container: {
    justifyContent: 'center',
    marginTop: 0,
    padding: 60,

    flex: 1,
    // borderWidth: 0,
    // alignSelf: 'center',,styles.dystyle]
    // alignItems: 'stretch',
    // justifyContent: 'center',
    // flexDirection: 'column',
  },
  title: {
    fontSize: 25,
    alignSelf: 'center',
    marginBottom: 30
  },
  buttonText: {
    fontSize: 18,
    color: 'white',
    alignSelf: 'center'
  },
  button: {
    paddingTop: 15,
    paddingBottom: 15,
    backgroundColor: '#000000',
    borderWidth: 0,
    borderRadius: 50,
    marginBottom: 10,
    marginTop: 10,
    borderRadius: 100,
    alignSelf: 'stretch',
    justifyContent: 'center',

  },
  textBlcok: {
    flex: 1,
    flexDirection: 'row',
    alignSelf: 'center',
  },
  newText: {
    fontSize: 18,
    alignSelf: 'center',
    fontWeight: 'normal',
    marginTop: 10,
    color: '#444',
    textDecorationLine: 'underline',
    paddingLeft: 5,
    paddingRight: 5
  },
  inputForm: {
    flex: 1,
    paddingTop: 10,
    paddingRight: 10,
    paddingBottom: 10,
    paddingLeft: 0,
    //backgroundColor: '#fff',
    color: '#000',
    borderWidth: 0,
  },

  inputSection: {
    borderBottomColor: '#bbb',
    borderBottomWidth: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    /*  backgroundColor: '#fff',
     borderBottomLeftRadius:20,
  borderBottomRightRadius: 20,
 borderTopLeftRadius: 20,
 borderTopRightRadius: 20*/
  },




  inputIcon: {
    padding: 10,
  }
});
