import React, { Component } from 'react';
import {
  BackHandler,
  StyleSheet,
  Text,
  View, Image,
  TouchableHighlight,
  ImageBackground,
} from 'react-native';
import axios from 'axios';
import Icon from 'react-native-vector-icons/FontAwesome';
import IconMaterial from 'react-native-vector-icons/MaterialCommunityIcons';
import { connect } from 'react-redux';
import profileImage from '../../image/user-default-profile.png';
import { updateRemoteUser, updateCallState, updateCallType, updateJoinState, updateRoomId } from '../actions/CallAction';
import LinearGradient from 'react-native-linear-gradient';
import { NavigationActions } from 'react-navigation';
import Toast from 'react-native-easy-toast';
import Loader from './Loader';
import Footer from './Footer';

class UsersDetailScreen extends React.Component {
  constructor(props) {
    super(props);
    this.state = { loading: false, myContacts: [], contactExists: false, paramUser: {} };
  }
  static navigationOptions = {
    title: 'User Detail',
  };

  async componentWillMount() {
    this.setState({ paramUser: this.props.navigation.state.params });
    await this.getUserContacts();
    BackHandler.addEventListener('hardwareBackPress', this.backPressed);
  }

  componentWillUnmount() {
    BackHandler.removeEventListener('hardwareBackPress', this.backPressed);
  }

  backPressed = () => {
    return;
    const navigateAction = NavigationActions.navigate({
      routeName: 'Home'
    });
    this.props.navigation.dispatch(navigateAction);
    return true;
  }


  makeCall(to) {
    const _p = this.props;
    if (_p.call.callState != null) {
      this._showToast('You are already on a call');
    } else {
      const from = _p.user,
        roomId = this._generateRoomId();
      // dispatching action to update room id
      _p.updateRemoteUser(to);
      _p.updateCallState('calling');
      _p.updateCallType('call');
      _p.updateRoomId(roomId);
      _p.services.makeCall(from, to, roomId, 'call');
    }
  }

  addToContact(userData) {
    const self = this;
    self.setState({
      loading: true
    });
    axios.post('https://twaapi.herokuapp.com/api/v1.0/users/saveUserContacts', {
      user_id: self.props.user._id,
      contact_id: userData._id
    })
      .then(function (response) {
        self.setState({
          loading: false
        });
        if (response.data.status == 200) {
          self.setState({ contactExists: true });
        }
        self._showToast(response.data.message);
      })
      .catch(function (error) {
        self.setState({ loading: false });
        self._showToast('An error occurred');
      });
  }

  getUserContacts() {
    const self = this;
    self.setState({ loading: true });
    axios.post('https://twaapi.herokuapp.com/api/v1.0/users/getContactList', {
      user_id: self.props.user._id,
    })
      .then(function (response) {
        self.setState({ loading: false });
        if (response.data.data && response.data.data.length) {
          const myContacts = response.data.data;
          self.setState({ myContacts });
          myContacts.map((c) => {
            if (c.user_id == self.props.user._id && self.state.paramUser._id == c.contact_id) {
              self.setState({ contactExists: true });
            }
          });
        }
      })
      .catch(function (error) {
        self.setState({ loading: false });
      });
  }

  removeContact(user) {
    const self = this;
    self.setState({ loading: true });
    axios.post('https://twaapi.herokuapp.com/api/v1.0/users/removeContact', {
      user_id: self.props.user._id,
      contact_id: user._id
    })
      .then(function (response) {
        self.setState({
          loading: false
        });
        if (response.data.status == 200) {
          self.setState({ contactExists: false });
        }
        self._showToast(response.data.message);
      })
      .catch(function (error) {
        self.setState({ loading: false });
        self._showToast('An error occurred');
      });
  }

  _generateRoomId() {
    const possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    let text = "";
    for (var i = 0; i < 25; i++) {
      text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    return text;
  }

  renderToast() {
    return <Toast ref="toast" />;
  }

  _showToast(msg, duration = 750) {
    this.refs.toast.show(msg, duration);
  }

  render() {
    const contactExists = this.state.contactExists,
      user = this.props.navigation.state.params;
    return (
      <View style={styles.container}>
        <Loader loading={this.state.loading} />
        {this.renderToast()}
        <LinearGradient colors={['#444', '#242e42', '#000']} style={styles.linearGradient}>
          <View style={styles.headerContainer}>
            <View style={styles.imageContainer}>
              <Image source={profileImage} style={styles.profileImage} />
            </View>
            <Text style={styles.profileName}>
              {user.name + "\n"}(LEO)
            </Text>
          </View>
        </LinearGradient>
        <View style={{ flex: 1, flexDirection: 'row' }}>
          <TouchableHighlight onPress={() => this._showToast('Feature is under construction')} style={styles.buttonVmail}>
            <View style={styles.blockInner}>
              <Icon style={styles.blockIcon} name="envelope" size={80} color="#fff" />
              <Text style={styles.blockText}>V-Mail</Text>
            </View>
          </TouchableHighlight>
          <TouchableHighlight onPress={() => this._showToast('Feature is under construction')} style={styles.buttonChat}>
            <View style={styles.blockInner}>
              <Icon style={styles.blockIcon} name="comments" size={80} color="#fff" />
              <Text style={styles.blockText}>Chat</Text>
            </View>
          </TouchableHighlight>
        </View>
        <View style={{ flex: 1, flexDirection: 'row', marginBottom: 20 }}>
          <TouchableHighlight onPress={() => this.makeCall(user)} style={styles.buttonCall}>
            <View style={styles.blockInner}>
              <Icon style={styles.blockIcon} name="video-camera" size={80} color="#fff" />
              <Text style={styles.blockText}>Video Conference</Text>
            </View>
          </TouchableHighlight>
          <TouchableHighlight onPress={() => contactExists ? this.removeContact(user) : this.addToContact(user)} style={contactExists ? styles.removeContact : styles.addContact}>
            <View style={styles.blockInner}>
              <IconMaterial style={styles.blockIcon} name="contacts" size={80} color="#fff" />
              <Text style={styles.blockText}>{contactExists ? 'Remove Contact' : 'Add To Contact'}</Text>
            </View>
          </TouchableHighlight>
        </View>
        <Footer />
      </View >
    );
  }
}
const styles = StyleSheet.create({
  linearGradient: {
    flex: 1,
    paddingTop: 20,
    paddingBottom: 10,
  },
  container: {
    paddingTop: 0,
    flex: 1,
    alignItems: 'stretch',
  },
  blockInner: {
    flex: 1,
    justifyContent: 'center',
  },
  blockIcon: {
    justifyContent: 'center',
    alignSelf: 'center',
  },
  buttonCall: {
    justifyContent: 'center',
    flex: 1,
    backgroundColor: '#4f830f',
    padding: 30,
  },
  addContact: {
    justifyContent: 'center',
    flex: 1,
    backgroundColor: '#eb6148',
    padding: 30,
  },
  removeContact: {
    justifyContent: 'center',
    flex: 1,
    backgroundColor: '#999',
    padding: 30,
  },
  buttonChat: {
    justifyContent: 'center',
    flex: 1,
    backgroundColor: '#31a0e6',
    padding: 30,
  },
  buttonVmail: {
    justifyContent: 'center',
    flex: 1,
    backgroundColor: '#eaa804',
    padding: 30,
  },
  blockText: {
    justifyContent: 'center',
    fontSize: 11,
    color: '#fff',
    alignSelf: 'center',
  },
  headerContainer: {
    flexDirection: 'column',
    flex: 1,
  },
  imageContainer: {
    flex: 0.4,
    borderRadius: 50,
    alignSelf: 'center',
    backgroundColor: '#fff',
    borderWidth: 8,
    borderColor: '#ccc'
  },
  profileImage: {
    width: 50,
    height: 50,
    alignSelf: 'center'
  },
  profileName: {
    flex: 0.6,
    fontSize: 12,
    alignSelf: 'center',
    color: '#fff',
    paddingTop: 10,
  },
});

const mapStateToProps = (state) => {
  return {
    call: state.call,
    services: state.services,
    user: state.users
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    updateRemoteUser: (remoteUser) => dispatch(updateRemoteUser(remoteUser)),
    updateCallState: (callState) => dispatch(updateCallState(callState)),
    updateCallType: (type) => dispatch(updateCallType(type)),
    updateJoinState: (joinState) => dispatch(updateJoinState(joinState)),
    updateRoomId: (id) => dispatch(updateRoomId(id))
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(UsersDetailScreen);
