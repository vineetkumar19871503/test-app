import React, { Component } from 'react';
import {
  Button, Text, View, StyleSheet, ImageBackground, TouchableOpacity, TouchableHighlight, Dimensions
} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import { showPopup } from '../actions/LayoutAction';
import { NavigationActions } from 'react-navigation';
import { connect } from 'react-redux';
import { logout } from '../actions/UserAction';
// import { RNCamera } from 'react-native-camera';

const landmarkSize = 2;

const flashModeOrder = {
  off: 'on',
  on: 'auto',
  auto: 'torch',
  torch: 'off',
};

const wbOrder = {
  auto: 'sunny',
  sunny: 'cloudy',
  cloudy: 'shadow',
  shadow: 'fluorescent',
  fluorescent: 'incandescent',
  incandescent: 'auto',
};

class VideoRecorder extends React.Component {

  state = {
    flash: 'off',
    zoom: 0,
    autoFocus: 'on',
    depth: 0,
    type: 'back',
    whiteBalance: 'auto',
    ratio: '16:9',
    ratios: [],
    photoId: 1,
    showGallery: false,
    photos: [],
    faces: [],
  };

  getRatios = async function() {
    const ratios = await this.camera.getSupportedRatios();
    return ratios;
  };

  toggleView() {
    this.setState({
      showGallery: !this.state.showGallery,
    });
  }

  toggleFacing() {
    this.setState({
      type: this.state.type === 'back' ? 'front' : 'back',
    });
  }

  toggleFlash() {
    this.setState({
      flash: flashModeOrder[this.state.flash],
    });
  }

  setRatio(ratio) {
    this.setState({
      ratio,
    });
  }

  toggleWB() {
    this.setState({
      whiteBalance: wbOrder[this.state.whiteBalance],
    });
  }

  toggleFocus() {
    this.setState({
      autoFocus: this.state.autoFocus === 'on' ? 'off' : 'on',
    });
  }

  zoomOut() {
    this.setState({
      zoom: this.state.zoom - 0.1 < 0 ? 0 : this.state.zoom - 0.1,
    });
  }

  zoomIn() {
    this.setState({
      zoom: this.state.zoom + 0.1 > 1 ? 1 : this.state.zoom + 0.1,
    });
  }

  setFocusDepth(depth) {
    this.setState({
      depth,
    });
  }

  takePicture = async function() {
    if (this.camera) {
      this.camera.takePictureAsync().then(data => {
        console.log('data: ', data);
      });
    }
  };
  _startRecording = async function() {
    if (this.camera) {
      await this.camera.recordAsync()
      .then(data => {console.log(data)})
      .catch(error => {console.log(error)})
      
      // .then(data => {
      //   console.log('start: ', data);
      // });
    }
  };
  _stopRecording = function() {
    // if (this.camera) {
      this.camera.stopRecording();
      // };
  };
/*
  onFacesDetected = ({ faces }) => this.setState({ faces });
  onFaceDetectionError = state => console.warn('Faces detection error:', state);

  renderFace({ bounds, faceID, rollAngle, yawAngle }) {
    return (
      <View
        key={faceID}
        transform={[
          { perspective: 600 },
          { rotateZ: `${rollAngle.toFixed(0)}deg` },
          { rotateY: `${yawAngle.toFixed(0)}deg` },
        ]}
        style={[
          styles.face,
          {
            ...bounds.size,
            left: bounds.origin.x,
            top: bounds.origin.y,
          },
        ]}
      >
        <Text style={styles.faceText}>ID: {faceID}</Text>
        <Text style={styles.faceText}>rollAngle: {rollAngle.toFixed(0)}</Text>
        <Text style={styles.faceText}>yawAngle: {yawAngle.toFixed(0)}</Text>
      </View>
    );
  }

  renderLandmarksOfFace(face) {
    const renderLandmark = position =>
      position && (
        <View
          style={[
            styles.landmark,
            {
              left: position.x - landmarkSize / 2,
              top: position.y - landmarkSize / 2,
            },
          ]}
        />
      );
    return (
      <View key={`landmarks-${face.faceID}`}>
        {renderLandmark(face.leftEyePosition)}
        {renderLandmark(face.rightEyePosition)}
        {renderLandmark(face.leftEarPosition)}
        {renderLandmark(face.rightEarPosition)}
        {renderLandmark(face.leftCheekPosition)}
        {renderLandmark(face.rightCheekPosition)}
        {renderLandmark(face.leftMouthPosition)}
        {renderLandmark(face.mouthPosition)}
        {renderLandmark(face.rightMouthPosition)}
        {renderLandmark(face.noseBasePosition)}
        {renderLandmark(face.bottomMouthPosition)}
      </View>
    );
  }

  renderFaces() {
    return (
      <View style={styles.facesContainer} pointerEvents="none">
        {this.state.faces.map(this.renderFace)}
      </View>
    );
  }

  renderLandmarks() {
    return (
      <View style={styles.facesContainer} pointerEvents="none">
        {this.state.faces.map(this.renderLandmarksOfFace)}
      </View>
    );
  }*/

  renderCamera() {
    return null;
    // return (
    //   <RNCamera
    //     ref={ref => {
    //       this.camera = ref;
    //     }}
    //     style={{
    //       flex: 1,
    //     }}
    //     type={this.state.type}
    //     flashMode={this.state.flash}
    //     autoFocus={this.state.autoFocus}
    //     zoom={this.state.zoom}
    //     whiteBalance={this.state.whiteBalance}
    //     ratio={this.state.ratio}
    //     // faceDetectionLandmarks={RNCamera.Constants.FaceDetection.Landmarks.all}
    //     // onFacesDetected={this.onFacesDetected}
    //     // onFaceDetectionError={this.onFaceDetectionError}
    //     focusDepth={this.state.depth}
    //     permissionDialogTitle={'Permission to use camera'}
    //     permissionDialogMessage={'We need your permission to use your camera phone'}
    //   >
        
    //     <View
    //       style={{
    //         flex: 0.1,
    //         backgroundColor: 'transparent',
    //         flexDirection: 'row',
    //         alignSelf: 'flex-end',
    //       }}
    //     >
          
    //       <TouchableOpacity
    //         style={[styles.flipButton, styles.picButton, { flex: 0.3, alignSelf: 'flex-end' }]}
    //         onPress={this._stopRecording.bind(this)}
    //       >
    //         <Text style={styles.flipText}> stop </Text>
    //       </TouchableOpacity>
    //       <TouchableOpacity
    //         style={[styles.flipButton, styles.picButton, { flex: 0.3, alignSelf: 'flex-end' }]}
    //         onPress={this._startRecording.bind(this)}
    //       >
    //         <Text style={styles.flipText}> start </Text>
    //       </TouchableOpacity>
    //       <TouchableOpacity
    //         style={[styles.flipButton, styles.picButton, { flex: 0.3, alignSelf: 'flex-end' }]}
    //         onPress={this.takePicture.bind(this)}
    //       >
    //         <Text style={styles.flipText}> SNAP </Text>
    //       </TouchableOpacity>
          
    //     </View>
    //     {/* {this.renderFaces()} */}
    //     {/* {this.renderLandmarks()} */}
    //   </RNCamera>
    // );
  }

  render() {
    return <View style={styles.container}>{this.renderCamera()}</View>;
  }
}

const mapStateToProps = (state) => {
  return {
    services: state.services,
    user: state.users,
    layout: state.layout
  }
}

const mapDispatchToProps = (dispatch) => {
  return {}
}

export default connect(mapStateToProps)(VideoRecorder);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 10,
    backgroundColor: '#000',
  },
  navigation: {
    flex: 1,
  },
  gallery: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  flipButton: {
    flex: 0.3,
    height: 40,
    marginHorizontal: 2,
    marginBottom: 10,
    marginTop: 20,
    borderRadius: 8,
    borderColor: 'white',
    borderWidth: 1,
    padding: 5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  flipText: {
    color: 'white',
    fontSize: 15,
  },
  item: {
    margin: 4,
    backgroundColor: 'indianred',
    height: 35,
    width: 80,
    borderRadius: 5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  picButton: {
    backgroundColor: 'darkseagreen',
  },
  galleryButton: {
    backgroundColor: 'indianred',
  },
  facesContainer: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    left: 0,
    top: 0,
  },
  face: {
    padding: 10,
    borderWidth: 2,
    borderRadius: 2,
    position: 'absolute',
    borderColor: '#FFD700',
    justifyContent: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  landmark: {
    width: landmarkSize,
    height: landmarkSize,
    position: 'absolute',
    backgroundColor: 'red',
  },
  faceText: {
    color: '#FFD700',
    fontWeight: 'bold',
    textAlign: 'center',
    margin: 10,
    backgroundColor: 'transparent',
  },
  row: {
    flexDirection: 'row',
  },
});



// export default Header