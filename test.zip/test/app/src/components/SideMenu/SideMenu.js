import PropTypes from 'prop-types';
import React, { Component } from 'react';
import styles from './SideMenu.style';
import { NavigationActions } from 'react-navigation';
import { StyleSheet, Text, View, ScrollView, TouchableOpacity, Image } from 'react-native';
import profileImage from '../../../image/user-default-profile.png';
import LinearGradient from 'react-native-linear-gradient';
// import videoStarting from '../components/videoStarting';

class SideMenu extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      user: null,
    }
  }
  navigateToScreen = (route) => () => {
    const navigateAction = NavigationActions.navigate({
      routeName: route
    });
    this.props.navigation.dispatch(navigateAction);
  }

  render() {
    return (
      <View style={styles.container}>
        <ScrollView>
          <LinearGradient colors={['#000000', '#242e42']} style={styles.linearGradient}>
            <View style={styles.headerContainer}>
              <View style={styles.imageContainer}>
                <Image source={profileImage} style={styles.profileImage} />
              </View>
              <Text style={styles.profileName}>
                {JSON.stringify(this.props.user)}
              </Text>
            </View>

            <View>
              {/* <Text style={styles.sectionHeadingStyle}>
              Section 1
            </Text> */}
              <View style={styles.navSectionStyle}>
                {/* <Text style={styles.navItemStyle} onPress={this.navigateToScreen('Login')}>
                Login
              </Text>
              <Text style={styles.navItemStyle} onPress={this.navigateToScreen('Registration')}>
                Registration
              </Text> 
              */}
              <Text style={styles.navItemStyle} onPress={this.navigateToScreen('Home')}>
                Home
              </Text>
              
                <Text style={styles.navItemStyle} onPress={this.navigateToScreen('Policy')}>
                  Privacy and Policy
              </Text>
                <Text style={styles.navItemStyle} onPress={this.navigateToScreen('About')}>
                  About
              </Text>
              {/* <Text style={styles.navItemStyle} onPress={this.navigateToScreen('VideoRecorder')}>
                VideoRecorder
              </Text>
              <Text style={styles.navItemStyle} onPress={this.navigateToScreen('Conference')}>
                Conference
              </Text> */}
              </View>
            </View>
          </LinearGradient>
        </ScrollView>
      </View>
    );
  }
}

SideMenu.propTypes = {
  navigation: PropTypes.object
};

export default SideMenu;


