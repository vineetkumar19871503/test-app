export default {
  linearGradient: {
    flex: 1,
    paddingTop: 20,
    paddingBottom: 10,
   
  },
  container: {
    paddingTop: 0,
    flex: 1,
    backgroundColor:'#242e42',
    // opacity:.8
  },
  navItemStyle: {
    color:'#fff',
    padding: 10,
    fontSize:20,
    borderBottomWidth:1,
    borderColor:'#171819'
    

  },
  navSectionStyle: {
    paddingVertical: 20,
    paddingHorizontal: 10,
    
    // backgroundColor: 'lightgrey'
  },
  sectionHeadingStyle: {
    color:'#fff',
    paddingVertical: 20,
    paddingHorizontal: 10,
  },
  footerContainer: {
    padding: 20,
    // backgroundColor: 'lightgrey'
  },
  headerContainer: {
    alignSelf: 'center',
  },
  imageContainer: {
    width:110,
    height:110,
    borderRadius:90,
    backgroundColor:'#fff',
    borderColor:'#ccc',
    borderWidth:6,
  },
  profileImage:{
    width: 75,
    height: 75, 
    alignSelf: 'center',
    paddingTop:10
  },
  profileName: {
    alignSelf:'center',
    color:'#fff',
    fontWeight:'bold',
    paddingTop:10,
  }
};