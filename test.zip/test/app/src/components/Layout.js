import React, { Component } from 'react';
import { NativeModules, Modal, View, Sound, StyleSheet, Text, TouchableHighlight, Vibration, PermissionsAndroid } from 'react-native';
import { connect } from 'react-redux';
import FullScreenVideo from "./FullScreenVideo.js";
import Home from './Home.js'
import Icon from 'react-native-vector-icons/FontAwesome';
import { RTCView } from 'react-native-webrtc';
import { StackNavigator } from 'react-navigation';
import { showPopup } from '../actions/LayoutAction';
import styles from '../../style/app';
import Thumbnails from "./Thumbnails.js";
import Toast from 'react-native-easy-toast';
import { updateRemoteUser, updateCallState, updateJoinState, updateCallType, updateRoomId } from '../actions/CallAction';
import LoudSpeaker from 'react-native-loud-speaker';
import LocationMessage from './LocationMessage';


class Layout extends Component {
    constructor(props) {
        super(props);
        this.state = {
            activeStreamUrl: null,
            audioMuted: false,
            callbacks: {
                onMakeCall: this.onMakeCall.bind(this),
                participantStreamAdded: this.participantStreamAdded.bind(this)
            },
            callee: null,
            callState: null,
            scRecorder: NativeModules.RecordingManager,
            isFrontCamera: true, // front or rear camera for switching
            incomingCall: false,
            isCallInitiator: false,  // set to true if logged in user initiated the call
            joinState: "ready", //ready/joining/joined
            participants: [],
            isRecording: false,
            selfStream: null,
            socketIO: null,
            streams: [],
            videoMsg: null,
            videoMuted: false
        };

        // binding methods
        this.acceptCall = this.acceptCall.bind(this);
        this.dropCall = this.dropCall.bind(this);
        this.rejectCall = this.rejectCall.bind(this);
        this.toggleCamera = this.toggleCamera.bind(this);
    }
    componentWillMount() {
        this.setState({ socketIO: this.props.services.getSocket() });
    }

    componentWillUnmount() {
        navigator.geolocation.clearWatch(this.watchID);
        this._resetCall();
    }

    componentDidMount() {
        this._getLocalStream();
        this.bindSocketEvents();
        this.props.services.bindComponentCallbacksToServices(this.state.callbacks);
    }

    bindSocketEvents() {
        const socket = this.state.socketIO,
            self = this;

        // bind events when socket is connected
        socket.on('connect', function (data) {
            socket.on('incoming_call', function (data) {
                const _p = self.props;
                _p.updateRemoteUser(data.from);
                if (_p.call.callState !== null) {
                    // if user is busy on other call then don't get incoming call and inform the caller
                    socket.emit('line_busy', { 'to': _p.call.remoteUser, 'from': _p.user });
                } else {
                    self._addParticipant(data.from);
                    _p.updateRoomId(data.room_id);
                    _p.updateCallType(data.call_type);
                    self._muteUnmuteVideo(false);
                    self.setState({ 'incomingCall': true, isCallInitiator: false });
                }
            });

            // when any participant joins a room
            socket.on("on_participant_joined", function (roomId, participant) {
                self._addParticipant(participant);
            });
            socket.on('participant_dropped_call', function (droppedBy) {
                self.onParticipantDroppedCall(droppedBy);
            });
            socket.on('participant_left', function (data) {
                // todo: remove participant from participants array
                self.onParticipantLeft(data);
            });
            socket.on('participant_rejected_call', function (rejecter) {
                self.onParticipantRejectedCall(rejecter);
            });
            socket.on('participant_busy', function (data) {
                self.onParticipantBusy(data);
            });
            socket.on('not_reachable', function () {
                self.onParticipantNotReachable();
            })
        });
    }

    onMakeCall() {
        // when user makes call then unmute audio+video
        this._muteMedia(false);
        this.startRecording();
        this.setState({ isCallInitiator: true });
    }

    dropCall() {
        const params = { 'dropped_by': this.props.user, 'room_id': this.props.call.roomId };
        if (this.props.call.callType == 'call') {
            params.drop_inform_to = this.props.call.remoteUser;
        }
        const remoteSocketId = this._getSocketIdOfParticipant(this.props.call.remoteUser);
        this.killStream(remoteSocketId);
        this.setState({ activeStreamUrl: this.state.selfStream.toURL() });
        this.props.services.dropCall(params);
        this._resetCall();
    }

    onParticipantDroppedCall(droppedBy) {
        // leave room if participant dropped the call in case of one-to-one calling
        this._showToast(droppedBy.name + ' dropped the call');
        const _p = this.props;
        if (_p.call.callType == 'call') {
            _p.services.leaveRoom(_p.call.roomId, _p.user.email);
            this._resetCall();
        }
        this.killStream(droppedBy.socketId);
    }

    onParticipantLeft(data) {
        this.killStream(data.user.socketId);
        this.props.services.leaveRoom();
    }

    onParticipantRejectedCall(rejecter) {
        this._resetCall();
        this._showToast(rejecter.name + ' rejected your call');
        // leave the room
        this.props.services.leaveRoom(this.props.call.roomId, this.props.user.email);
    }

    onParticipantBusy() {
        this._showToast('Line is busy of ' + this.props.call.remoteUser.name);
        this._resetCall();
    }

    onParticipantNotReachable() {
        this._resetCall();
        this._showToast('Not reachable');
        // leave the room
        this.props.services.leaveRoom(this.props.call.roomId, this.props.user.email);
    }

    participantStreamAdded(socketId, stream) {
        const self = this;
        let streams = this.state.streams,
            newState = {},
            _sUrl = stream.toURL();
        // if its a one-to-one call and the first participant joins then show him on full screen
        if (streams.length == 1 && this.props.call.callType == 'call') {
            newState.activeStreamUrl = _sUrl;
        }
        // filter existing stream by socket id
        streams = streams.filter(function (str) {
            return str.socketId != socketId;
        });
        streams.push({
            socketId,
            streamObj: stream,
            url: _sUrl
        });
        newState.streams = streams;
        this.setState(newState);
        setTimeout(function () {
            self._loudSpeaker(true);
            self.startRecording();
        }, 100);
    }

    async acceptCall() {
        const self = this;
        //await self._getLocalStream();
        self._muteMedia(false);
        // join the room
        self.props.services.join(self.props.call.roomId, self.props.user.email, function (participants) {
            self.props.updateJoinState('joined');
            self.props.updateCallState('picked');
        });
        Vibration.cancel();
        this.setState({ 'incomingCall': false });
    }
    rejectCall() {
        this._resetCall();
        this.props.services.rejectCall(this.props.user, this.props.call.remoteUser);
    }
    toggleCamera() {
        const self = this,
            _st = self.state,
            facingMode = !_st.isFrontCamera;
        self.props.services.toggleCamera(facingMode, function (stream) {
            // remove existing stream
            const newStreams = _st.streams.filter(function (str) {
                if (str.socketId != _st.socketIO.id) {
                    return str;
                }_showToast
            })
            const _sU = stream.toURL();
            newStreams.push({
                socketId: _st.socketIO.id,
                streamObj: stream,
                url: _sU
            });
            self.setState({
                isFrontCamera: facingMode,
                selfStream: stream,
                activeStreamUrl: _sU,
                streams: newStreams
            });
        });
    }

    renderCallOptions() {
        const self = this;
        if (this.state.incomingCall) {
            return (
                <Modal
                    animationType="slide"
                    transparent={false}
                    visible={true}
                    onRequestClose={() => {
                        self._showToast('Line is busy of ' + this.props.call.remoteUser.name);
                    }}>
                    <View style={{
                        flex: 1,
                        backgroundColor: 'black',
                        flexDirection: 'column',
                        justifyContent: 'center',
                        alignItems: 'center'
                    }}><Icon name='phone' size={90} color="#fff" />
                        <Text style={{ color: 'white', flexDirection: 'row', fontSize: 30 }}>{this.props.call.remoteUser.name}</Text>
                        <Text style={{ color: 'white', flexDirection: 'row', paddingBottom: 150 }}>calling you...</Text>
                        <View style={{ flexDirection: 'row' }}>
                            <TouchableHighlight onPress={this.acceptCall} style={btnStyles.accept}>
                                <Text style={{ color: '#fff', fontSize: 20 }}>Accept</Text>
                            </TouchableHighlight>
                            <TouchableHighlight onPress={this.rejectCall} style={btnStyles.reject}>
                                <Text style={{ color: '#fff', fontSize: 20 }}>Reject</Text>
                            </TouchableHighlight>
                        </View>
                    </View>
                </Modal>
            );
        }
        return null;
    }

    renderToast() {
        return <Toast ref="toast" />;
    }

    // record screen once the call is connected
    startRecording() {
        if (!this.state.isRecording) {
            const recordingName = this._getRecordingName();
            this.state.scRecorder.startRecording(recordingName);
            this.setState({ isRecording: true });
        }
    }

    // stop the recording when call ends
    stopRecording() {
        if (this.state.isRecording) {
            this.state.scRecorder.stopRecording();
            this.setState({ isRecording: false });
        }
    }

    killStream(socketId = null) {
        const streams = this.state.streams;
        for (let str = 0; str < streams.length; str++) {
            if (streams[str].socketId == socketId) {
                this.props.services.destroyPeerConnection(socketId, streams[str].streamObj);
                streams.splice(str, 1);
                break;
            }
        }
        this.setState({ streams });
    }

    /**
     * some private methods
     */
    _addParticipant(participant) {
        const participants = this.state.participants;
        participants.push(participant);
        this.setState({ participants });
    }
    _getSocketIdOfParticipant(participant) {
        let socketId = null,
            _p = this.state.participants;
        for (let p = 0; p < _p.length; p++) {
            if (_p[p].email == participant.email) {
                socketId = _p[p].socketId;
                break;
            }
        }
        return socketId;
    }

    _getLocalStream() {
        const self = this,
            _st = self.state;
        // getting the client's steam and setting it into state
        self.props.services.getLocalStream(self.state.isFrontCamera, (stream) => {
            const _sU = stream.toURL(),
                streams = _st.streams;
            streams.push({
                socketId: _st.socketIO.id,
                streamObj: stream,
                url: _sU
            });
            self.setState({
                selfStream: stream,
                activeStreamUrl: _sU,
                streams: streams
            });
        });
    }

    _getRecordingName() {
        let name = (this.props.user.name + '-' + this.props.call.remoteUser.name).replace(/ +/g, "").toLowerCase();
        const d = new Date(),
            dtTm = d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate() + '_' + d.getHours() + '-' + d.getMinutes() + '-' + d.getSeconds();
        name += '_' + dtTm;
        return name;
    }

    _muteUnmuteAudio(mute = true) {
        const _ss = this.state.selfStream;
        if (_ss) {
            this.setState({ 'audioMuted': mute });
            _ss.getAudioTracks()[0].enabled = mute ? false : true;
        }
    }
    _muteUnmuteVideo(mute = true) {
        const _ss = this.state.selfStream;
        if (_ss) {
            let msg = mute ? 'Video is muted...' : null;
            this.setState({ 'videoMuted': mute, 'videoMsg': msg });
            _ss.getVideoTracks()[0].enabled = mute ? false : true;
        }
    }

    // mute both audio and video
    _muteMedia(mute = true) {
        this._muteUnmuteAudio(mute);
        this._muteUnmuteVideo(mute);
    }

    _resetCall() {
        //this.killStream(this.state.socketIO.id);
        this.stopRecording();
        this.props.updateCallState(null);
        this.props.updateJoinState('ready');
        this.setState({
            'incomingCall': false,
            'activeStreamUrl': this.state.selfStream.toURL(),
            'isCallInitiator': false
        });
        Vibration.cancel();
        this._loudSpeaker(false);
    }

    _showToast(msg, duration = 750) {
        this.refs.toast.show(msg, duration);
    }

    _loudSpeaker(status = true) {
        LoudSpeaker.open(status);
    }

    render() {
        const callState = this.props.call.callState,
            isCalling = callState == "calling",
            callPicked = callState == "picked";
        if (this.state.incomingCall) {
            Vibration.vibrate([0, 500, 500], true);
        }
        return (
            <View style={{ flex: 1 }} >
            <LocationMessage />
                {this.renderCallOptions()}
                {this.renderToast()}
                {isCalling || callPicked
                    ?
                    <View style={{ backgroundColor: '#000' }}>
                        <Text style={styles.videoMsg}>{this.state.videoMsg}</Text>
                        <FullScreenVideo streamURL={this.state.activeStreamUrl} />
                        <View style={styles.callOptions}>
                            {/* <Icon
                                style={styles.callOptIcon}
                                onPress={this.toggleCamera}
                                name='camera'
                                size={28}
                                color="#fff" /> */}
                            <Icon
                                style={styles.callOptIcon}
                                onPress={() => this._muteUnmuteAudio(!this.state.audioMuted)}
                                name={this.state.audioMuted ? 'microphone-slash' : 'microphone'}
                                size={28}
                                color="#fff" />
                            <TouchableHighlight
                                style={styles.dropButton}
                                onPress={this.dropCall} >
                                <Icon
                                    name="phone"
                                    size={25}
                                    color="#fff" />
                            </TouchableHighlight>
                            <Icon
                                style={styles.callOptIcon}
                                onPress={() => this._muteUnmuteVideo(!this.state.videoMuted)}
                                name={this.state.videoMuted ? 'video-camera' : 'video-camera'}
                                size={28}
                                color="#fff" />
                        </View>
                        <Thumbnails streams={this.state.streams}
                            setActive={(streamUrl) => this.setState({ 'activeStreamUrl': streamUrl })}
                            activeStreamUrl={this.state.activeStreamUrl} />
                    </View>
                    :
                    null
                }
                {this.props.children}
            </View>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        call: state.call,
        services: state.services,
        user: state.users
    };
}

const mapDispatchToProps = (dispatch) => {
    return {
        showPopup: (isShowPopup) => dispatch(showPopup(isShowPopup)),
        updateRemoteUser: (remoteUser) => dispatch(updateRemoteUser(remoteUser)),
        updateCallState: (callState) => dispatch(updateCallState(callState)),
        updateJoinState: (joinState) => dispatch(updateJoinState(updateJoinState)),
        updateCallType: (type) => dispatch(updateCallType(type)),
        updateRoomId: (roomId) => dispatch(updateRoomId(roomId))
    }
}

const btnStyles = StyleSheet.create({
    accept: {
        padding: 20,
        marginRight: 5,
        backgroundColor: 'green'
    },
    reject: {
        padding: 20,
        marginRight: 5,
        backgroundColor: 'red'
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(Layout);