import React, { Component } from 'react';
import {
  Button, Text, View, StyleSheet, ImageBackground, AsyncStorage
} from 'react-native';
import { connect } from 'react-redux';
import { FormLabel, FormInput } from 'react-native-elements';
import Icon from 'react-native-vector-icons/FontAwesome';
import Loader from './Loader';
class Policy extends React.Component {
  static navigationOptions = {
    title: 'Policy/Privacy',
  };

  constructor(props) {
    super(props);
    this.state = { loading: true };
  }

  componentWillMount() {
    // AsyncStorage.removeItem('email');
    AsyncStorage.getItem('email').then((value) => {
      if (value) {
        this.setState({ loader: false, logged: true, email: value })
      } else {
        this.setState({ loader: false })
      }
    })
  }
  testSocket() {
    this.props.services.testSocketMapping();
  }
  render() {
    return (
      <View style={styles.container}>
        <View style={{flexDirection:'column'}}>
          <View style={styles.header}>
            <Text style={{fontWeight:'bold'}}> Contact </Text>
          </View>
          <Text style={{ fontWeight: 'bold', fontSize: 20 }} > Kollel Ohr Haemet </Text>
          <Text>112 Steamboat Rd </Text>
          <Text>Great Neck, NY 11024</Text>
          <View style={styles.innerContent}>
            <Text style={styles.textHead}>
              Phone:
          </Text>
            <Text style={styles.textValue}>
              (516)487-6080
          </Text>
          </View>
          <View style={styles.innerContent}>
            <Text style={styles.textHead}>
              Text:
          </Text>
            <Text style={styles.textValue}>
              (516)888-6080
          </Text>
          </View>
          <View style={styles.innerContent}>
            <Text style={styles.textHead}>
              Email:
          </Text>
            <Text style={styles.textValue}>
              info@greatneckkollel.org
          </Text>
          </View>
          <View style={styles.innerContent}>
            <Text style={styles.textHead}>
              Web:
          </Text>
            <Text style={styles.textValue}>
              greatneckkollel.org
          </Text>
          </View>
        </View>

        <View style={{alignItems: 'stretch', alignSelf: 'flex-end' }}>
          <Text style={{ fontWeight: 'bold', fontSize: 20 }} > To Join Our Mailing List <Text style={{ color: 'blue', textDecorationLine: 'underline' }}>click here</Text> </Text>
          <Text style={{ fontWeight: 'bold', fontSize: 20 }} > To Donate <Text style={{ color: 'blue', textDecorationLine: 'underline' }}>click here</Text> </Text>
        </View>
        <View style={{alignSelf: 'stretch', flexDirection:'column' }}>
          <Text style={{ fontSize: 15 }} > Useful links:</Text>
          <Text style={{ fontSize: 15 }} > Kollel printer friendly Minyan schedule <Text style={{ color: 'blue', textDecorationLine: 'underline' }}>click here</Text> </Text>
          <Text style={{ fontSize: 15 }} > Great Neck Zmanim <Text style={{ color: 'blue', textDecorationLine: 'underline' }}>click here</Text> </Text>
        </View>
        <View style={{backgroundColor: '#DDDDDD',padding: 5,}}>
          <Text style={{ fontSize: 15 }} > Published by <Text style={{ color: 'blue', textDecorationLine: 'underline' }}>Google Drive</Text>
           --
           <Text style={{ color: 'blue', textDecorationLine: 'underline' }}>Report Abuse</Text>
           --
           Updated automatically wvery 5 minutes
            </Text>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // flexDirection: 'column',
    // alignItems: 'stretch',
    // justifyContent: 'center',
  },
  header: {
    height: 50, backgroundColor: '#DDDDDD',
    padding: 10, alignSelf: 'stretch',
  },
  innerContent: {
    flexDirection: 'row',
  },
  textHead: {
    lineHeight: 25,
    fontSize: 15,
    fontWeight: 'bold',
  },
  textValue: {
    lineHeight: 25,
    fontSize: 15,
  }
});

const mapStateToProps = (state) => {
  return {
    services: state.services
  }
}
export default connect(mapStateToProps)(Policy);