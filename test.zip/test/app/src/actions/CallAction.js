export function updateRemoteUser(remoteUser) {
    return {
        type: 'UPDATE_REMOTE_USER',
        payload: remoteUser
    }
}

export function updateCallState(state) {
    return {
        type: 'UPDATE_CALL_STATE',
        payload: state
    }
}

export function updateCallType(type) {
    return {
        type: 'UPDATE_CALL_TYPE',
        payload: type
    }
}

export function updateJoinState(state) {
    return {
        type: 'UPDATE_JOIN_STATE',
        payload: state
    }
}

export function updateRoomId(roomId) {
    return {
        type: 'UPDATE_ROOM_ID',
        payload: roomId
    }
}