export function showPopup(showPopup = false) {
    return {
        type: 'SHOW_POPUP',
        payload: showPopup
    }
}
