export function login(userData = {}) {
    return {
        type: 'LOGIN',
        payload: userData
    }
}

export function logout() {
    return {
        type: 'LOGOUT'
    }
}

export function updateLocation(location) {
    return {
        type: 'UPDATE_LOCATION',
        payload: location
    }
}