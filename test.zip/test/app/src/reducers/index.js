import { combineReducers } from 'redux';
import UsersReducer from './UserReducer';
import ServicesReducer from './ServicesReducer';
import CallReducer from './CallReducer';
import LayoutReducer from './LayoutReducer';
const rootReducer = combineReducers({
    call: CallReducer,
    users: UsersReducer,
    services: ServicesReducer,
    layout: LayoutReducer,
});
export default rootReducer;