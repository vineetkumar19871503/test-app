const UsersReducer = (state = {}, action) => {
    const _s = Object.assign({}, state);
    switch (action.type) {
        case 'LOGIN':
            action.payload.isLoggedIn = true;
            return Object.assign({}, _s, action.payload);
        case 'LOGOUT':
            return { isLoggedIn: false };
        case 'UPDATE_LOCATION':
            _s.location = action.payload;
            return _s;
        default:
            return state
    }
}
export default UsersReducer;