import React from 'react';
import { StackNavigator } from 'react-navigation';
import Layout from '../components/Layout';
import Login from '../components/Login';
import Conference from '../components/Conference';
import Home from '../components/Home';
import UserDetail from '../components/UserDetail';
import UsersListing from '../components/UsersListing';
import Registration from '../components/Registration';
import Policy from '../components/Policy';
import LocationMessage from '../components/LocationMessage';
import About from '../components/About';
import Header from '../components/Header';
import VideoRecorder from '../components/VideoRecorder';
import ForgotPassword from '../components/ForgotPassword';
const Routes = StackNavigator({
    Login: {
        screen: Login,
        navigationOptions: { header: null }
    },
    UserDetail: { screen: UserDetail, navigationOptions: ({ navigation }) => ({ header: props => <Header nav={navigation} headerTitle="User Detail" /> }) },
    //UsersListing: { screen: UsersListing,navigationOptions: ({navigation}) => ({header: props => <Header nav={navigation} headerTitle="Users" />}) },
    UsersListing: { screen: UsersListing, navigationOptions: ({ navigation }) => ({ header: props => <Header nav={navigation} headerTitle="Listing" /> }) },
    Conference: { screen: Conference, navigationOptions: { header: null } },
    Home: { screen: Home, navigationOptions: ({ navigation }) => ({ header: props => <Header nav={navigation} headerTitle="Home" /> }) },
    Registration: { screen: Registration, navigationOptions: ({ navigation }) => ({ header: props => <Header nav={navigation} headerTitle="SignUp" /> }) },
    VideoRecorder: { screen: VideoRecorder, navigationOptions: { navigation: null } },
    Layout: { screen: Layout },
    Policy: { screen: Policy, navigationOptions: ({ navigation }) => ({ header: props => <Header nav={navigation} headerTitle="Policy" /> }) },
    About: { screen: About, navigationOptions: ({ navigation }) => ({ header: props => <Header nav={navigation} headerTitle="About" /> }) },
    ForgotPassword: { screen: ForgotPassword, navigationOptions: ({ navigation }) => ({ header: props => <Header nav={navigation} headerTitle="Password Recovery" /> }) },
    LocationMessage: { screen: LocationMessage, navigationOptions: { header: null } },
});
export default Routes;
