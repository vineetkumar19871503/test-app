import React from 'react';
import { StyleSheet, Text, View, ScrollView } from 'react-native';
import { DrawerNavigator } from 'react-navigation';
import SideMenu from '../components/SideMenu/SideMenu';
import Routes from './routes';
export default DrawerNavigator({
  Routes: {
    screen: Routes
  }
},
  {
    contentComponent: SideMenu,
    drawerWidth: 300,
    // headerMode: 'none',
    initialRouteName: 'Routes',
  },
  {
    // define customComponent here
    contentComponent: props =>
      <ScrollView>
        <DrawerItems {...props} />
        <Text>Your Own Footer Area After</Text>
      </ScrollView>
  });
