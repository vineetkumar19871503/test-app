import { AppRegistry } from 'react-native';
import App from "./src/App.js";

AppRegistry.registerComponent('native1', () => App);
