package com.native1;

import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;

import java.lang.ref.WeakReference;

public class CallNotificationManager extends ReactContextBaseJavaModule {

    private static final String TAG = "CallNotificationManager";
    private static WeakReference<MainActivity> mWeakActivity;

    private static ReactApplicationContext mReactContext;

    public static void updateActivity(MainActivity activity) {
        mWeakActivity = new WeakReference<MainActivity>(activity);
    }

    public CallNotificationManager(ReactApplicationContext reactContext) {
        super(reactContext);
        mReactContext = reactContext;
    }

    @Override
    public String getName() {
        return "CallNotificationManager";
    }

    @ReactMethod
    public void showNotification() {
        mWeakActivity.get().showNotification();
    }

    @ReactMethod
    public void hideNotification() {
        mWeakActivity.get().showNotification();
    }
}
