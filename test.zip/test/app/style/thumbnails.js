import { StyleSheet } from 'react-native';
import config from "../src/config/";

export default StyleSheet.create({
  container: {
    position: "absolute",
    height: config.thumbnailHeight,
    width: config.screenWidth,
    bottom: 0,
    left: 0
  },
  thumbnailContainer: {
    flexDirection: 'row',
    flex: 1,
    top: 0,
    position: 'absolute',
    zIndex: 999
  },
  thumbnail: {
    height: 50,
    width: 50
  },
  activeThumbnail: {
    borderColor: "#CCC", borderWidth: 2
  }
});
